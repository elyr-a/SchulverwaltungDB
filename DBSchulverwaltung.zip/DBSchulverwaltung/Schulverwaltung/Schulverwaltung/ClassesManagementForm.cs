﻿using SchulVerwaltung.Database;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Schulverwaltung
{
    public partial class ClassesManagementForm : Form
    {
        private enum ManagementMode { LehrerFach, Fach }
        private ManagementMode currentMode = ManagementMode.LehrerFach;

        private int selectedLehrerFachId = -1;
        private int selectedFachId = -1;
        public ClassesManagementForm()
        {
            InitializeComponent();

            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
        }

        private void ClassesManagementForm_Load(object sender, EventArgs e)
        {
            PopulateDropdowns();
            UpdateViewMode();
        }

        // Swap managament mode
        private void btn_Toggle_Click(object sender, EventArgs e)
        {
            currentMode = (currentMode == ManagementMode.LehrerFach) ? ManagementMode.Fach : ManagementMode.LehrerFach;
            UpdateViewMode();
        }

        // Toggle visibility for input panels and refresh grid data based on current management mode
        private void UpdateViewMode()
        {
            ResetInputControls();

            if (currentMode == ManagementMode.LehrerFach)
            {
                pnl_LehrerFach.Visible = true;
                pnl_Fach.Visible = false;
            }
            else
            {
                pnl_LehrerFach.Visible = false;
                pnl_Fach.Visible = true;
            }

            RefreshGrid();
        }

        // Fills lookup collection with correspoding database entries
        private void PopulateDropdowns()
        {
            string sqlLehrer = "SELECT LehrerID, CONCAT(Nachname, ', ', Vorname) AS Name FROM lehrer ORDER BY Nachname";
            DataTable dtLehrer = DatabaseHelper.ExecuteQuery(sqlLehrer);
            cmb_Lehrer.DataSource = dtLehrer;
            cmb_Lehrer.DisplayMember = "Name";
            cmb_Lehrer.ValueMember = "LehrerID";

            string sqlFaecher = "SELECT FachID, Name FROM faecher ORDER BY Name";
            DataTable dtFaecher = DatabaseHelper.ExecuteQuery(sqlFaecher);
            cmb_Fach.DataSource = dtFaecher;
            cmb_Fach.DisplayMember = "Name";
            cmb_Fach.ValueMember = "FachID";

            string sqlKlassen = "SELECT KlasseID, Name FROM klassen ORDER BY Name";
            DataTable dtKlassen = DatabaseHelper.ExecuteQuery(sqlKlassen);
            cmb_Klasse.DataSource = dtKlassen;
            cmb_Klasse.DisplayMember = "Name";
            cmb_Klasse.ValueMember = "KlasseID";
        }


        /// Reloads grid
        private void RefreshGrid()
        {
            string sql = string.Empty;

            if (currentMode == ManagementMode.LehrerFach)
            {
                sql = @"SELECT lf.LehrerFachID, 
                               CONCAT(l.Nachname, ', ', l.Vorname) AS Teacher, 
                               f.Name AS Subject, 
                               k.Name AS Class
                        FROM lehrer_fach lf
                        JOIN lehrer l ON lf.LehrerID = l.LehrerID
                        JOIN faecher f ON lf.FachID = f.FachID
                        JOIN klassen k ON lf.KlasseID = k.KlasseID
                        ORDER BY k.Name, l.Nachname";
            }
            else
            {
                sql = "SELECT FachID, Name, Kuerzel AS Abbreviation FROM faecher ORDER BY Name";
            }

            DataTable dt = DatabaseHelper.ExecuteQuery(sql);
            dgv_Classes.DataSource = dt;

            dgv_Classes.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            if (dgv_Classes.Columns["LehrerFachID"] != null) dgv_Classes.Columns["LehrerFachID"].Visible = false;
            if (dgv_Classes.Columns["FachID"] != null) dgv_Classes.Columns["FachID"].Visible = false;
        }

        // Populate input fields on row click with corresponding data
        private void dgv_Classes_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            DataGridViewRow row = dgv_Classes.Rows[e.RowIndex];

            if (currentMode == ManagementMode.LehrerFach)
            {
                selectedLehrerFachId = Convert.ToInt32(row.Cells["LehrerFachID"].Value);
                cmb_Lehrer.Text = row.Cells["Teacher"].Value.ToString();
                cmb_Fach.Text = row.Cells["Subject"].Value.ToString();
                cmb_Klasse.Text = row.Cells["Class"].Value.ToString();
            }
            else
            {
                selectedFachId = Convert.ToInt32(row.Cells["FachID"].Value);
                textBox1.Text = row.Cells["Name"].Value.ToString();
                textBox2.Text = row.Cells["Abbreviation"].Value.ToString();
            }
        }

        // Add 
        private void btn_Add_Click(object sender, EventArgs e)
        {
            if (!ValidateInputs(isEditMode: false)) return;

            try
            {
                if (currentMode == ManagementMode.LehrerFach)
                {
                    string sql = "INSERT INTO lehrer_fach (LehrerID, FachID, KlasseID) VALUES (@lId, @fId, @kId)";
                    DatabaseHelper.ExecuteNonQuery(sql,
                        ("lId", cmb_Lehrer.SelectedValue),
                        ("fId", cmb_Fach.SelectedValue),
                        ("kId", cmb_Klasse.SelectedValue)
                    );
                }
                else
                {
                    string sql = "INSERT INTO faecher (Name, Kuerzel) VALUES (@name, @kuerzel)";
                    DatabaseHelper.ExecuteNonQuery(sql,
                        ("name", textBox1.Text.Trim()),
                        ("kuerzel", textBox2.Text.Trim().ToUpper())
                    );
                    PopulateDropdowns();
                }

                MessageBox.Show("Added succesfully.", 
                    "Success", 
                    MessageBoxButtons.OK, 
                    MessageBoxIcon.Information);
                UpdateViewMode();
            }
            catch (Exception ex) { MessageBox.Show($"Error: {ex.Message}"); }
        }

        // Edit
        private void btn_Edit_Click(object sender, EventArgs e)
        {
            if ((currentMode == ManagementMode.LehrerFach && selectedLehrerFachId == -1) ||
                (currentMode == ManagementMode.Fach && selectedFachId == -1))
            {
                MessageBox.Show("Please select a registry first.", 
                    "No Selection", 
                    MessageBoxButtons.OK, 
                    MessageBoxIcon.Warning);
                return;
            }
            if (!ValidateInputs(isEditMode: true)) return;

            try
            {
                if (currentMode == ManagementMode.LehrerFach)
                {
                    string sql = "UPDATE lehrer_fach SET LehrerID = @lId, FachID = @fId, KlasseID = @kId WHERE LehrerFachID = @lfId";
                    DatabaseHelper.ExecuteNonQuery(sql,
                        ("lId", cmb_Lehrer.SelectedValue),
                        ("fId", cmb_Fach.SelectedValue),
                        ("kId", cmb_Klasse.SelectedValue),
                        ("lfId", selectedLehrerFachId)
                    );
                }
                else
                {
                    string sql = "UPDATE faecher SET Name = @name, Kuerzel = @kuerzel WHERE FachID = @fId";
                    DatabaseHelper.ExecuteNonQuery(sql,
                        ("name", textBox1.Text.Trim()),
                        ("kuerzel", textBox2.Text.Trim().ToUpper()),
                        ("fId", selectedFachId)
                    );
                    PopulateDropdowns();
                }

                MessageBox.Show("Edited succesfully.", 
                    "Success",
                    MessageBoxButtons.OK, 
                    MessageBoxIcon.Information);
                UpdateViewMode();
            }
            catch (Exception ex) { MessageBox.Show($"Error: {ex.Message}"); }
        }

        /// Executes deletion commands with cascade warnings and confirmation prompts.
        private void btn_Del_Click(object sender, EventArgs e)
        {
            if ((currentMode == ManagementMode.LehrerFach && selectedLehrerFachId == -1) ||
                (currentMode == ManagementMode.Fach && selectedFachId == -1))
            {
                MessageBox.Show("Please select a registry first.", 
                    "No Selection", 
                    MessageBoxButtons.OK, 
                    MessageBoxIcon.Warning);
                return;
            }

            try
            {
                if (currentMode == ManagementMode.LehrerFach)
                {
                    // Count how many timetable entries are currently linked to this teacher-subject assignment for a transparent warning
                    string sqlCount = "SELECT COUNT(*) FROM stundenplan WHERE LehrerFachID = @lfId";
                    DataTable dt = DatabaseHelper.ExecuteQuery(sqlCount, ("lfId", selectedLehrerFachId));
                    int activeLessons = (dt.Rows.Count > 0) ? Convert.ToInt32(dt.Rows[0][0]) : 0;

                    string warningMsg = "Are you sure you want to permanently delete this teacher-subject assignment?";
                    if (activeLessons > 0)
                    {
                        warningMsg = $"WARNING: This assignment is currently used in {activeLessons} scheduled lesson(s) on the timetable.\n\n" +
                                     "Deleting it will automatically REMOVE those lessons from the timetable layout via database cascade!\n\n" +
                                     "Do you still want to proceed?";
                    }

                    var confirm = MessageBox.Show(warningMsg, "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                    if (confirm != DialogResult.Yes) return;

                    string sqlDel = "DELETE FROM lehrer_fach WHERE LehrerFachID = @lfId";
                    DatabaseHelper.ExecuteNonQuery(sqlDel, ("lfId", selectedLehrerFachId));
                }
                else
                {
                    // Count how many teacher-subject assignments and timetable entries are linked to this subject for a transparent warning about the cascade effect
                    string sqlCountCascade = @"
                        SELECT 
                            (SELECT COUNT(*) 
                             FROM lehrer_fach 
                             WHERE FachID = @fId) AS LinkedAssignments,
                            (SELECT COUNT(*) 
                             FROM stundenplan s 
                             JOIN lehrer_fach lf ON s.LehrerFachID = lf.LehrerFachID 
                             WHERE lf.FachID = @fId) AS LinkedLessons";

                    DataTable dtCascade = DatabaseHelper.ExecuteQuery(sqlCountCascade, ("fId", selectedFachId));
                    int linkedAssignments = Convert.ToInt32(dtCascade.Rows[0]["LinkedAssignments"]);
                    int linkedLessons = Convert.ToInt32(dtCascade.Rows[0]["LinkedLessons"]);

                    string warningMsg = "Are you sure you want to permanently delete this subject from the registry?";
                    if (linkedAssignments > 0 || linkedLessons > 0)
                    {
                        warningMsg = $"CRITICAL WARNING: Deleting this subject will trigger a system-wide cascade!\n\n" +
                                     $"This action will automatically erase:\n" +
                                     $" -> {linkedAssignments} Teacher-Subject assignment links\n" +
                                     $" -> {linkedLessons} Scheduled lessons from class timetables\n\n" +
                                     "This action cannot be undone. Do you absolute wish to execute this cascade?";
                    }

                    var confirm = MessageBox.Show(warningMsg, 
                        "CRITICAL: Confirm System Cascade", 
                        MessageBoxButtons.YesNo, 
                        MessageBoxIcon.Error);
                    if (confirm != DialogResult.Yes) return;

                    string sqlDel = "DELETE FROM faecher WHERE FachID = @fId";
                    DatabaseHelper.ExecuteNonQuery(sqlDel, ("fId", selectedFachId));
                    PopulateDropdowns(); 
                }

                MessageBox.Show("All associated datas have been deleted succesfully.", 
                    "Success", 
                    MessageBoxButtons.OK, 
                    MessageBoxIcon.Information);
                UpdateViewMode();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error during cascade: {ex.Message}");
            }
        }

        // Prevents duplicates and validates non-empty fields based on active management mode.
        private bool ValidateInputs(bool isEditMode)
        {
            if (currentMode == ManagementMode.LehrerFach)
            {
                if (cmb_Lehrer.SelectedValue == null || cmb_Fach.SelectedValue == null || cmb_Klasse.SelectedValue == null)
                {
                    MessageBox.Show("All lookup fields must point to structural target elements.", 
                        "Validation Error", 
                        MessageBoxButtons.OK, 
                        MessageBoxIcon.Error);
                    return false;
                }

                string sqlDupCheck = @"SELECT COUNT(*) FROM lehrer_fach 
                                       WHERE LehrerID = @lId AND FachID = @fId AND KlasseID = @kId AND (@isEdit = 0 OR LehrerFachID != @lfId)";

                DataTable dt = DatabaseHelper.ExecuteQuery(sqlDupCheck,
                    ("lId", cmb_Lehrer.SelectedValue),
                    ("fId", cmb_Fach.SelectedValue),
                    ("kId", cmb_Klasse.SelectedValue),
                    ("isEdit", isEditMode ? 1 : 0),
                    ("lfId", selectedLehrerFachId)
                );

                // Duplicate entry
                if (dt.Rows.Count > 0 && Convert.ToInt32(dt.Rows[0][0]) > 0)
                {
                    MessageBox.Show("This already exists.", 
                        "Duplicate Exists", 
                        MessageBoxButtons.OK, 
                        MessageBoxIcon.Warning);
                    return false;
                }
            }
            else
            {
                if (string.IsNullOrWhiteSpace(textBox1.Text) || string.IsNullOrWhiteSpace(textBox2.Text))
                {
                    MessageBox.Show("Subject name and abbreviation can not be blank.", 
                        "Validation Error", 
                        MessageBoxButtons.OK, 
                        MessageBoxIcon.Error);
                    return false;
                }

                string sqlDupCheck = "SELECT COUNT(*) FROM faecher WHERE (Name = @name OR Kuerzel = @kuerzel) AND (@isEdit = 0 OR FachID != @fId)";
                DataTable dt = DatabaseHelper.ExecuteQuery(sqlDupCheck,
                    ("name", textBox1.Text.Trim()),
                    ("kuerzel", textBox2.Text.Trim().ToUpper()),
                    ("isEdit", isEditMode ? 1 : 0),
                    ("fId", selectedFachId)
                );

                if (dt.Rows.Count > 0 && Convert.ToInt32(dt.Rows[0][0]) > 0)
                {
                    MessageBox.Show("Duplicate already exists.", 
                        "Duplicate Constraint Match", 
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }
            }

            return true;
        }

        // Resets all inputs
        private void ResetInputControls()
        {
            selectedLehrerFachId = -1;
            selectedFachId = -1;
            textBox1.Clear();
            textBox2.Clear();

            if (cmb_Lehrer.Items.Count > 0) cmb_Lehrer.SelectedIndex = 0;
            if (cmb_Fach.Items.Count > 0) cmb_Fach.SelectedIndex = 0;
            if (cmb_Klasse.Items.Count > 0) cmb_Klasse.SelectedIndex = 0;
        }
    }
}
