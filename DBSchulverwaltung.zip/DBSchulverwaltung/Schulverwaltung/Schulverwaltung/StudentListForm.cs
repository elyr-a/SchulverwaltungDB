﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using SchulVerwaltung.Helpers;
using SchulVerwaltung.Database;

namespace Schulverwaltung
{
    public partial class StudentListForm : Form
    {
        private int selectedStudentId = -1;
        private int selectedTeacherId = -1;

        private enum ViewMode { Students, Teachers }
        private ViewMode currentMode = ViewMode.Students;
        public StudentListForm()
        {
            InitializeComponent();

            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
        }

        private void StudentListForm_Load(object sender, EventArgs e)
        {
            RefreshStudentGrid();
            LoadClassComboBox();

            dgv_Students.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        private void SwitchViewMode(ViewMode newMode)
        {
            currentMode = newMode;
            ClearInputFields();
            UpdateViewMode();

            if (currentMode == ViewMode.Students)
            {
                lbl_DropdownCaption.Text = "Klasse:";
                lbl_Geburtsdatum.Text = "Geburtsdatum:";
                dtp_Birthdate.Visible = true;
                lbl_Mail.Visible = false;
                txt_Password.Visible = false;

                LoadClassComboBox();
                RefreshStudentGrid();
            }
            else
            {
                lbl_DropdownCaption.Text = "Rolle:";
                lbl_Geburtsdatum.Visible = false;
                dtp_Birthdate.Visible = false;

                LoadTeacherRolesComboBox();
                RefreshTeacherGrid();
            }
        }

        private void UpdateViewMode()
        {
            if (currentMode == ViewMode.Students)
            {
                btn_Students.BackColor = Color.LightGreen;
                btn_Teachers.BackColor = SystemColors.Control;
            }
            else
            {
                btn_Teachers.BackColor = Color.LightGreen;
                btn_Students.BackColor = SystemColors.Control;
            }
        }

        // Retrieves student data from the database and displays it in the DataGridView
        private void RefreshStudentGrid()
        {
            string sql = "SELECT s.SchuelerID, s.Vorname, s.Nachname, s.Geburtsdatum, k.Name AS 'Class', s.Benutzername " +
                         "FROM schueler s " +
                         "JOIN klassen k ON s.KlasseID = k.KlasseID " +
                         "ORDER BY k.Name, s.Nachname";

            dgv_Students.DataSource = DatabaseHelper.ExecuteQuery(sql);

            if (dgv_Students.Columns["SchuelerID"] != null)
                dgv_Students.Columns["SchuelerID"].Visible = false;
        }

        private void LoadTeacherRolesComboBox()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("Display");
            dt.Columns.Add("Value");
            dt.Rows.Add("Lehrer", "Lehrer");
            dt.Rows.Add("Admin", "Admin");

            cmb_Class.DataSource = dt;
            cmb_Class.DisplayMember = "Display";
            cmb_Class.ValueMember = "Value";
        }

        // Retrieves teacher data from the database and displays it in the DataGridView
        private void RefreshTeacherGrid()
        {
            string sql = "SELECT LehrerID, Vorname, Nachname, Email, Benutzername, Rolle FROM lehrer ORDER BY Nachname, Vorname";
            dgv_Students.DataSource = DatabaseHelper.ExecuteQuery(sql);

            if (dgv_Students.Columns["LehrerID"] != null) dgv_Students.Columns["LehrerID"].Visible = false;
            if (dgv_Students.Columns["SchuelerID"] != null) dgv_Students.Columns["SchuelerID"].Visible = false;
        }

        // Loads class names into the combo box for selection
        private void LoadClassComboBox()
        {
            string sql = "SELECT KlasseID, Name FROM klassen ORDER BY Name";
            DataTable dt = DatabaseHelper.ExecuteQuery(sql);

            cmb_Class.DataSource = dt;
            cmb_Class.DisplayMember = "Name";
            cmb_Class.ValueMember = "KlasseID";
        }

        // Populates input fields with the selected student's or teacher's information when a cell is clicked in the DataGridView
        private void dgv_Students_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || dgv_Students.Rows[e.RowIndex].IsNewRow) return;

            DataGridViewRow row = dgv_Students.Rows[e.RowIndex];

            if (currentMode == ViewMode.Students)
            {
                if (row.Cells["SchuelerID"].Value == null || row.Cells["SchuelerID"].Value == DBNull.Value) return;

                selectedStudentId = Convert.ToInt32(row.Cells["SchuelerID"].Value);
                selectedTeacherId = -1;

                txt_Vorname.Text = row.Cells["Vorname"].Value?.ToString() ?? "";
                txt_Nachname.Text = row.Cells["Nachname"].Value?.ToString() ?? "";
                txt_Username.Text = row.Cells["Benutzername"].Value?.ToString() ?? "";
                cmb_Class.Text = row.Cells["Class"].Value?.ToString() ?? "";

                if (row.Cells["Geburtsdatum"].Value != DBNull.Value)
                    dtp_Birthdate.Value = Convert.ToDateTime(row.Cells["Geburtsdatum"].Value);
            }
            else
            {
                if (row.Cells["LehrerID"].Value == null || row.Cells["LehrerID"].Value == DBNull.Value) return;

                selectedTeacherId = Convert.ToInt32(row.Cells["LehrerID"].Value);
                selectedStudentId = -1;

                txt_Vorname.Text = row.Cells["Vorname"].Value?.ToString() ?? "";
                txt_Nachname.Text = row.Cells["Nachname"].Value?.ToString() ?? "";
                txt_Username.Text = row.Cells["Benutzername"].Value?.ToString() ?? "";
                txt_Password.Text = row.Cells["Email"].Value?.ToString() ?? "";
                cmb_Class.SelectedValue = row.Cells["Rolle"].Value?.ToString() ?? "Lehrer";

                // txt_Email.Text = row.Cells["Email"].Value?.ToString() ?? "";
            }
        }

        // Adds a new student to the database 
        private void btn_Add_Click(object sender, EventArgs e)
        {
            if (!ValidateInputs()) return;

            string lowercaseUsername = txt_Username.Text.Trim().ToLower();
            string defaultPasswordHash = PasswordHelper.HashPassword("start123", lowercaseUsername);

            if (currentMode == ViewMode.Students)
            {
                string sql = "INSERT INTO schueler (Vorname, Nachname, Geburtsdatum, KlasseID, Benutzername, PasswortHash) " +
                             "VALUES (@vorname, @nachname, @geburtsdatum, @klasseId, @username, @passwordHash)";

                DatabaseHelper.ExecuteNonQuery(sql,
                    ("vorname", txt_Vorname.Text.Trim()),
                    ("nachname", txt_Nachname.Text.Trim()),
                    ("geburtsdatum", dtp_Birthdate.Value.ToString("yyyy-MM-dd")),
                    ("klasseId", cmb_Class.SelectedValue),
                    ("username", lowercaseUsername),
                    ("passwordHash", defaultPasswordHash)
                );

                MessageBox.Show("Student registered successfully! Temporary password is: start123", 
                    "Success", 
                    MessageBoxButtons.OK, 
                    MessageBoxIcon.Information);
                RefreshStudentGrid();
            }
            else
            {
                string generatedEmail = $"{lowercaseUsername}@schule.de";

                string sql = "INSERT INTO lehrer (Vorname, Nachname, Email, Benutzername, PasswortHash, Rolle) " +
                             "VALUES (@vorname, @nachname, @email, @username, @passwordHash, @rolle)";

                DatabaseHelper.ExecuteNonQuery(sql,
                    ("vorname", txt_Vorname.Text.Trim()),
                    ("nachname", txt_Nachname.Text.Trim()),
                    ("email", generatedEmail),
                    ("username", lowercaseUsername),
                    ("passwordHash", defaultPasswordHash),
                    ("rolle", cmb_Class.SelectedValue.ToString())
                );

                MessageBox.Show($"Teacher registered successfully!\nEmail: {generatedEmail}\nTemporary password is: start123", 
                    "Success", 
                    MessageBoxButtons.OK, 
                    MessageBoxIcon.Information);
                RefreshTeacherGrid();
            }

            ClearInputFields();
        }

        // Checks if all required input fields are filled
        private bool ValidateInputs()
        {
            if (string.IsNullOrEmpty(txt_Vorname.Text) || string.IsNullOrEmpty(txt_Nachname.Text) || string.IsNullOrEmpty(txt_Username.Text) || cmb_Class.SelectedValue == null)
            {
                MessageBox.Show("All input fields must be populated.", 
                    "Validation Error", 
                    MessageBoxButtons.OK, 
                    MessageBoxIcon.Error);
                return false;
            }
            return true;
        }

        // Clears all input fields 
        private void ClearInputFields()
        {
            selectedStudentId = -1;
            selectedTeacherId = -1;
            txt_Vorname.Clear();
            txt_Nachname.Clear();
            txt_Username.Clear();
            dtp_Birthdate.Value = DateTime.Now;
            if (cmb_Class.Items.Count > 0)
                cmb_Class.SelectedIndex = 0;
        }

        // Edits the selected student/teacher information in the database
        private void btn_Edit_Click(object sender, EventArgs e)
        {
            if (!ValidateInputs()) return;

            if (currentMode == ViewMode.Students)
            {
                if (selectedStudentId == -1)
                {
                    MessageBox.Show("Please select a student to edit.", 
                        "No Selection", 
                        MessageBoxButtons.OK, 
                        MessageBoxIcon.Warning);
                    return;
                }

                string sql = "UPDATE schueler SET Vorname = @vorname, Nachname = @nachname, Geburtsdatum = @geburtsdatum, KlasseID = @klasseId, Benutzername = @username WHERE SchuelerID = @studentId";
                DatabaseHelper.ExecuteNonQuery(sql,
                    ("vorname", txt_Vorname.Text.Trim()),
                    ("nachname", txt_Nachname.Text.Trim()),
                    ("geburtsdatum", dtp_Birthdate.Value.ToString("yyyy-MM-dd")),
                    ("klasseId", cmb_Class.SelectedValue),
                    ("username", txt_Username.Text.Trim().ToLower()),
                    ("studentId", selectedStudentId)
                );

                MessageBox.Show("Student metrics updated successfully.", 
                    "Success", 
                    MessageBoxButtons.OK, 
                    MessageBoxIcon.Information);
                RefreshStudentGrid();
            }
            else
            {
                if (selectedTeacherId == -1)
                {
                    MessageBox.Show("Please select a teacher to edit.", 
                        "No Selection", 
                        MessageBoxButtons.OK, 
                        MessageBoxIcon.Warning);
                    return;
                }

                string lowercaseUser = txt_Username.Text.Trim().ToLower();

                string sql = "UPDATE lehrer SET Vorname = @vorname, Nachname = @nachname, Email = @email, Benutzername = @username, Rolle = @rolle WHERE LehrerID = @teacherId";
                DatabaseHelper.ExecuteNonQuery(sql,
                    ("vorname", txt_Vorname.Text.Trim()),
                    ("nachname", txt_Nachname.Text.Trim()),
                    ("email", txt_Password.Text),
                    ("username", lowercaseUser),
                    ("rolle", cmb_Class.SelectedValue.ToString()),
                    ("teacherId", selectedTeacherId)
                );

                MessageBox.Show("Teacher metrics updated successfully.", 
                    "Success", 
                    MessageBoxButtons.OK, 
                    MessageBoxIcon.Information);
                RefreshTeacherGrid();
            }

            ClearInputFields();
        }

        // Permanently deletes the selected student/teacher from the database after confirmation
        private void btn_Delete_Click(object sender, EventArgs e)
        {
            if (currentMode == ViewMode.Students)
            {
                if (selectedStudentId == -1)
                {
                    MessageBox.Show("Please select a student from the list first.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                DialogResult confirm = MessageBox.Show("Are you sure you want to permanently delete this student record?" +
                    "\nThis will remove their entire history, grades, and absence listings cascade-style.", 
                    "Critical Warning", 
                    MessageBoxButtons.YesNo, 
                    MessageBoxIcon.Warning);
                if (confirm == DialogResult.Yes)
                {
                    string sql = "DELETE FROM schueler WHERE SchuelerID = @studentId";
                    DatabaseHelper.ExecuteNonQuery(sql, ("studentId", selectedStudentId));

                    MessageBox.Show("Student completely purged from registry.", 
                        "Data Dropped", 
                        MessageBoxButtons.OK, 
                        MessageBoxIcon.Information);
                    RefreshStudentGrid();
                    ClearInputFields();
                }
            }
            else
            {
                if (selectedTeacherId == -1)
                {
                    MessageBox.Show("Please select a teacher from the list first.", 
                        "No Selection", 
                        MessageBoxButtons.OK, 
                        MessageBoxIcon.Warning);
                    return;
                }

                DialogResult confirm = MessageBox.Show("Are you sure you want to permanently delete this teacher record?" +
                    "\nThis will clear scheduled course maps and context relations cascade-style.", 
                    "Critical Warning", 
                    MessageBoxButtons.YesNo, 
                    MessageBoxIcon.Warning);
                if (confirm == DialogResult.Yes)
                {
                    string sql = "DELETE FROM lehrer WHERE LehrerID = @teacherId";
                    DatabaseHelper.ExecuteNonQuery(sql, ("teacherId", selectedTeacherId));

                    MessageBox.Show("Teacher completely purged from registry database layer.", 
                        "Data Dropped", 
                        MessageBoxButtons.OK, 
                        MessageBoxIcon.Information);
                    RefreshTeacherGrid();
                    ClearInputFields();
                }
            }
        }

        private void btn_Students_Click(object sender, EventArgs e)
        {
            SwitchViewMode(ViewMode.Students);
        }

        private void btn_Teachers_Click(object sender, EventArgs e)
        {
            SwitchViewMode(ViewMode.Teachers);
        }
    }
}
