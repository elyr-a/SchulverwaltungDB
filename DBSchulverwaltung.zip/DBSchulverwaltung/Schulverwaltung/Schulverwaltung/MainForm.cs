﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using SchulVerwaltung.Helpers;
using SchulVerwaltung.Database;

namespace Schulverwaltung
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();

            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            lbl_CurrentSession.Text = $"Welcome, {SessionHelper.Vollname}";

            ConfigureUIPermissions();
        }

        // Restricts or grants access to UI controls based on the user's role
        private void ConfigureUIPermissions()
        {
            if (SessionHelper.Role != SessionHelper.UserRole.Admin)
            {
                btn_LehrerFach.Enabled = false;
                btn_StudentList.Enabled = false;

                btn_LehrerFach.Visible = false;
                btn_StudentList.Visible = false;
            }
        }

        // Logout
        private void btn_Logout_Click(object sender, EventArgs e)
        {
            SessionHelper.Logout();

            LoginForm loginForm = new LoginForm();
            loginForm.Show();

            this.Hide();
            this.Dispose();
        }

        private void btn_MyClasses_Click(object sender, EventArgs e)
        {
            if (SessionHelper.Role == SessionHelper.UserRole.Schueler)
            {
                MyClassesForm myClassesForm = new MyClassesForm();
                myClassesForm.Show();
            }       
            else
            {
                TeacherClassesForm teacherClassesForm = new TeacherClassesForm();
                teacherClassesForm.Show();
            }
        }

        private void btn_StudentList_Click(object sender, EventArgs e)
        {
            StudentListForm studentListForm = new StudentListForm();
            studentListForm.Show();
        }

        private void btn_Stundenplan_Click(object sender, EventArgs e)
        {
            StundenPlanForm stundenPlanForm = new StundenPlanForm();
            stundenPlanForm.Show();
        }

        private void btn_LehrerFach_Click(object sender, EventArgs e)
        {
            ClassesManagementForm classesManagementForm = new ClassesManagementForm();
            classesManagementForm.Show();
        }

        private void btn_Fehlzeiten_Click(object sender, EventArgs e)
        {
            FehlzeitenForm fehlzeitenForm = new FehlzeitenForm();
            fehlzeitenForm.Show();
        }
    }
}