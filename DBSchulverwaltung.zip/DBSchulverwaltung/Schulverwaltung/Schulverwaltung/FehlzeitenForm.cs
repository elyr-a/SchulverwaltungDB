﻿using SchulVerwaltung.Database;
using SchulVerwaltung.Helpers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Schulverwaltung
{
    public partial class FehlzeitenForm : Form
    {
        private int selectedFehlzeitId = -1;

        public FehlzeitenForm()
        {
            InitializeComponent();

            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
        }

        // Loads data based on role
        private void FehlzeitenForm_Load(object sender, EventArgs e)
        {
            ConfigureFormComponents();

            if (SessionHelper.Role == SessionHelper.UserRole.Schueler)
            {
                pnl_1.Visible = false;
                dgv_Fehlzeiten.Dock = DockStyle.Fill;
            }
            else
            {
                pnl_1.Visible = true;
                LoadKlassenDropdown();
            }

            RefreshGrid();
        }

        // Initial configuration of form objects
        private void ConfigureFormComponents()
        {
            num_Stunden.Minimum = 1;
            num_Stunden.Maximum = 12;
            num_Stunden.Value = 1;
            dtp_Datum.Value = DateTime.Now;
        }

        // Load the class dropdown
        private void LoadKlassenDropdown()
        {
            try
            {
                string sql = "SELECT KlasseID, Name FROM klassen ORDER BY Name";
                DataTable dt = DatabaseHelper.ExecuteQuery(sql);

                if (dt.Rows.Count > 0)
                {
                    cmb_Klasse.DataSource = dt;
                    cmb_Klasse.DisplayMember = "Name";
                    cmb_Klasse.ValueMember = "KlasseID";

                    if (cmb_Klasse.SelectedValue is int firstKlasseId)
                    {
                        LoadSchuelerDropdown(firstKlasseId);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        // When a class is selected, refresh the dropdown to match the data
        private void cmb_Klasse_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmb_Klasse.SelectedValue != null && int.TryParse(cmb_Klasse.SelectedValue.ToString(), out int klasseId))
            {
                LoadSchuelerDropdown(klasseId);
            }
        }

        // Load students for dropdown based on selected class
        private void LoadSchuelerDropdown(int klasseId)
        {
            try
            {
                string sql = @"
                    SELECT SchuelerID, CONCAT(Nachname, ', ', Vorname) AS StudentName 
                    FROM schueler 
                    WHERE KlasseID = @kId 
                    ORDER BY Nachname, Vorname";

                DataTable dt = DatabaseHelper.ExecuteQuery(sql, ("kId", klasseId));

                cmb_Schueler.DataSource = dt;
                cmb_Schueler.DisplayMember = "StudentName";
                cmb_Schueler.ValueMember = "SchuelerID";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        // Populate grid with user-specific based on role
        private void RefreshGrid()
        {
            try
            {
                string sql;
                DataTable dt;

                if (SessionHelper.Role == SessionHelper.UserRole.Schueler)
                {
                    sql = @"SELECT f.Datum, f.Stunden, IF(f.Entschuldigt = 1, 'Ja', 'Nein') AS Entschuldigt, 
                                   f.Grund, CONCAT(l.Nachname, ', ', l.Vorname) AS Erfasst_Von 
                            FROM fehlzeiten f 
                            LEFT JOIN lehrer l ON f.ErfasstVon = l.LehrerID 
                            WHERE f.SchuelerID = @uId ORDER BY f.Datum DESC";
                    dt = DatabaseHelper.ExecuteQuery(sql, ("uId", SessionHelper.CurrentUserID));
                }
                else if (SessionHelper.Role == SessionHelper.UserRole.Lehrer)
                {
                    sql = @"SELECT DISTINCT f.FehlzeitID, f.SchuelerID, s.KlasseID, CONCAT(s.Nachname, ', ', s.Vorname) AS Schueler, 
                                   f.Datum, f.Stunden, IF(f.Entschuldigt = 1, 'Ja', 'Nein') AS Entschuldigt, 
                                   f.Grund, CONCAT(l.Nachname, ', ', l.Vorname) AS Erfasst_Von 
                            FROM fehlzeiten f 
                            JOIN schueler s ON f.SchuelerID = s.SchuelerID 
                            JOIN lehrer_fach lf ON s.KlasseID = lf.KlasseID 
                            LEFT JOIN lehrer l ON f.ErfasstVon = l.LehrerID 
                            WHERE lf.LehrerID = @tId ORDER BY f.Datum DESC";
                    dt = DatabaseHelper.ExecuteQuery(sql, ("tId", SessionHelper.CurrentUserID));
                }
                else
                {
                    sql = @"SELECT f.FehlzeitID, f.SchuelerID, s.KlasseID, CONCAT(s.Nachname, ', ', s.Vorname) AS Schueler, 
                                   f.Datum, f.Stunden, IF(f.Entschuldigt = 1, 'Ja', 'Nein') AS Entschuldigt, 
                                   f.Grund, CONCAT(l.Nachname, ', ', l.Vorname) AS Erfasst_Von 
                            FROM fehlzeiten f 
                            JOIN schueler s ON f.SchuelerID = s.SchuelerID 
                            LEFT JOIN lehrer l ON f.ErfasstVon = l.LehrerID 
                            ORDER BY f.Datum DESC";
                    dt = DatabaseHelper.ExecuteQuery(sql);
                }
            
                dgv_Fehlzeiten.DataSource = dt;
                dgv_Fehlzeiten.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                if (dgv_Fehlzeiten.Columns["SchuelerID"] != null)
                    dgv_Fehlzeiten.Columns["SchuelerID"].Visible = false;
                if (dgv_Fehlzeiten.Columns["KlasseID"] != null)
                    dgv_Fehlzeiten.Columns["KlasseID"].Visible = false;
                if (dgv_Fehlzeiten.Columns["FehlzeitID"] != null) dgv_Fehlzeiten.Columns["FehlzeitID"].Visible = false;               
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        // Add
        private void btn_Add_Click(object sender, EventArgs e)
        {
            if (SessionHelper.Role == SessionHelper.UserRole.Schueler) return; 
            if (cmb_Schueler.SelectedValue == null)
            {
                MessageBox.Show("Pick a student first.", 
                    "No Student", 
                    MessageBoxButtons.OK, 
                    MessageBoxIcon.Warning);
                return;
            }

            try
            {
                string sql = @"
                    INSERT INTO fehlzeiten (SchuelerID, Datum, Stunden, Entschuldigt, Grund, ErfasstVon)
                    VALUES (@sId, @datum, @stunden, @entschuldigt, @grund, @lehrerId)";

                DatabaseHelper.ExecuteNonQuery(sql,
                    ("sId", cmb_Schueler.SelectedValue),
                    ("datum", dtp_Datum.Value.ToString("yyyy-MM-dd")),
                    ("stunden", (int)num_Stunden.Value),
                    ("entschuldigt", chk_Entschuldigt.Checked ? 1 : 0),
                    ("grund", string.IsNullOrWhiteSpace(txt_Grund.Text) ? (object)DBNull.Value : txt_Grund.Text.Trim()),
                    ("lehrerId", SessionHelper.CurrentUserID)
                );

                MessageBox.Show("Added succesfully.", 
                    "Success", 
                    MessageBoxButtons.OK, 
                    MessageBoxIcon.Information);
                RefreshGrid();
                ResetInputControls();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        // Edit
        private void btn_Edit_Click(object sender, EventArgs e)
        {
            if (SessionHelper.Role == SessionHelper.UserRole.Schueler) return;
            if (selectedFehlzeitId == -1)
            {
                MessageBox.Show("Please select a Fehlzeit first.", 
                    "No Selection", 
                    MessageBoxButtons.OK, 
                    MessageBoxIcon.Warning);
                return;
            }

            try
            {
                string sql = @"
                    UPDATE fehlzeiten 
                    SET SchuelerID = @sId,
                        Datum = @datum,
                        Stunden = @stunden,
                        Entschuldigt = @entschuldigt,
                        Grund = @grund
                    WHERE FehlzeitID = @fId";

                DatabaseHelper.ExecuteNonQuery(sql,
                    ("sId", cmb_Schueler.SelectedValue),
                    ("datum", dtp_Datum.Value.ToString("yyyy-MM-dd")),
                    ("stunden", (int)num_Stunden.Value),
                    ("entschuldigt", chk_Entschuldigt.Checked ? 1 : 0),
                    ("grund", string.IsNullOrWhiteSpace(txt_Grund.Text) ? (object)DBNull.Value : txt_Grund.Text.Trim()),
                    ("fId", selectedFehlzeitId)
                );

                MessageBox.Show("Succesfully edited.", 
                    "Success", 
                    MessageBoxButtons.OK, 
                    MessageBoxIcon.Information);
                RefreshGrid();
                ResetInputControls();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        // Delete
        private void btn_Delete_Click(object sender, EventArgs e)
        {
            if (SessionHelper.Role == SessionHelper.UserRole.Schueler) return; 
            if (selectedFehlzeitId == -1)
            {
                MessageBox.Show("Please select a Fehlzeit first.", 
                    "No Selection", 
                    MessageBoxButtons.OK, 
                    MessageBoxIcon.Warning);
                return;
            }

            DialogResult confirm = MessageBox.Show("Are you sure you want to delete it?", 
                "Confirmation", 
                MessageBoxButtons.OKCancel, 
                MessageBoxIcon.Question);
            if (confirm != DialogResult.OK) return;

            try
            {
                string sql = "DELETE FROM fehlzeiten WHERE FehlzeitID = @fId";
                DatabaseHelper.ExecuteNonQuery(sql, ("fId", selectedFehlzeitId));

                MessageBox.Show("Succesfully deleted.", 
                    "Success", 
                    MessageBoxButtons.OK, 
                    MessageBoxIcon.Information);
                RefreshGrid();
                ResetInputControls();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", 
                    "Execution Fault", 
                    MessageBoxButtons.OK, 
                    MessageBoxIcon.Error);
            }
        }

        // Populates the input 
        private void dgv_Fehlzeiten_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || SessionHelper.Role == SessionHelper.UserRole.Schueler) return;

            try
            {
                DataGridViewRow row = dgv_Fehlzeiten.Rows[e.RowIndex];

                // Kind of a bulletproof way to prevent null errors
                if (dgv_Fehlzeiten.Columns.Contains("FehlzeitID") && row.Cells["FehlzeitID"].Value != DBNull.Value && row.Cells["FehlzeitID"].Value != null)
                {
                    selectedFehlzeitId = Convert.ToInt32(row.Cells["FehlzeitID"].Value);
                }

                if (dgv_Fehlzeiten.Columns.Contains("Schueler") && row.Cells["Schueler"].Value != DBNull.Value)
                {
                    string targetFullTextName = row.Cells["Schueler"].Value.ToString();
                    int targetKlasseId = Convert.ToInt32(row.Cells["KlasseID"].Value);

                    cmb_Klasse.SelectedIndexChanged -= cmb_Klasse_SelectedIndexChanged;
                    cmb_Klasse.SelectedValue = targetKlasseId;
                    LoadSchuelerDropdown(targetKlasseId);
                    cmb_Klasse.SelectedIndexChanged += cmb_Klasse_SelectedIndexChanged;

                    int foundIndex = cmb_Schueler.FindStringExact(targetFullTextName);
                    if (foundIndex != -1)
                    {
                        cmb_Schueler.SelectedIndex = foundIndex;
                    }
                    else
                    {
                        cmb_Schueler.SelectedIndex = -1; 
                    }
                }

                if (row.Cells["Datum"].Value != DBNull.Value && row.Cells["Datum"].Value != null)
                {
                    dtp_Datum.Value = Convert.ToDateTime(row.Cells["Datum"].Value);
                }

                if (row.Cells["Stunden"].Value != DBNull.Value && row.Cells["Stunden"].Value != null)
                {
                    num_Stunden.Value = Convert.ToInt32(row.Cells["Stunden"].Value);
                }

                if (row.Cells["Entschuldigt"].Value != DBNull.Value && row.Cells["Entschuldigt"].Value != null)
                {
                    chk_Entschuldigt.Checked = row.Cells["Entschuldigt"].Value.ToString() == "Ja";
                }
                else
                {
                    chk_Entschuldigt.Checked = false;
                }

                var grundValue = row.Cells["Grund"].Value;
                if (grundValue == DBNull.Value || grundValue == null)
                {
                    txt_Grund.Text = string.Empty;
                }
                else
                {
                    txt_Grund.Text = grundValue.ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        // Resets the input
        private void ResetInputControls()
        {
            selectedFehlzeitId = -1;
            dtp_Datum.Value = DateTime.Now;
            num_Stunden.Value = 1;
            chk_Entschuldigt.Checked = false;
            txt_Grund.Clear();
        }
    }
}
