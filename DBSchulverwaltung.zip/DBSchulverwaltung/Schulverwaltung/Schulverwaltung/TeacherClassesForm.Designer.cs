﻿namespace Schulverwaltung
{
    partial class TeacherClassesForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btn_LessonHistory = new Button();
            dgv_Grades = new DataGridView();
            dgv_StudentsAndLH = new DataGridView();
            dgv_Classes = new DataGridView();
            btn_Students = new Button();
            txt_Thema = new TextBox();
            txt_Inhalt = new TextBox();
            txt_Homework = new TextBox();
            txt_Page = new TextBox();
            txt_Note = new TextBox();
            cmb_Typ = new ComboBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            btn_DelGrade = new Button();
            btn_ = new Button();
            btn_AddGrade = new Button();
            label4 = new Label();
            txt_Beschreibung = new TextBox();
            dtp1 = new DateTimePicker();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            cmb_Gewichtung = new ComboBox();
            cmb_Note = new ComboBox();
            btn_AddLH = new Button();
            btn_EditLH = new Button();
            btn_DelLH = new Button();
            ((System.ComponentModel.ISupportInitialize)dgv_Grades).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgv_StudentsAndLH).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgv_Classes).BeginInit();
            SuspendLayout();
            // 
            // btn_LessonHistory
            // 
            btn_LessonHistory.ForeColor = SystemColors.ActiveCaptionText;
            btn_LessonHistory.Location = new Point(995, 457);
            btn_LessonHistory.Name = "btn_LessonHistory";
            btn_LessonHistory.Size = new Size(75, 52);
            btn_LessonHistory.TabIndex = 9;
            btn_LessonHistory.Text = "Lesson History";
            btn_LessonHistory.UseVisualStyleBackColor = true;
            btn_LessonHistory.Click += btn_LessonHistory_Click;
            // 
            // dgv_Grades
            // 
            dgv_Grades.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgv_Grades.Location = new Point(811, 10);
            dgv_Grades.Name = "dgv_Grades";
            dgv_Grades.Size = new Size(254, 201);
            dgv_Grades.TabIndex = 6;
            dgv_Grades.CellClick += dgv_Grades_CellClick;
            // 
            // dgv_StudentsAndLH
            // 
            dgv_StudentsAndLH.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgv_StudentsAndLH.Location = new Point(12, 235);
            dgv_StudentsAndLH.Name = "dgv_StudentsAndLH";
            dgv_StudentsAndLH.Size = new Size(776, 198);
            dgv_StudentsAndLH.TabIndex = 5;
            dgv_StudentsAndLH.CellClick += dgv_StudentsAndLH_CellClick;
            // 
            // dgv_Classes
            // 
            dgv_Classes.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgv_Classes.Location = new Point(12, 10);
            dgv_Classes.Name = "dgv_Classes";
            dgv_Classes.Size = new Size(776, 201);
            dgv_Classes.TabIndex = 4;
            dgv_Classes.CellClick += dgv_Classes_CellClick;
            // 
            // btn_Students
            // 
            btn_Students.ForeColor = SystemColors.ActiveCaptionText;
            btn_Students.Location = new Point(995, 515);
            btn_Students.Name = "btn_Students";
            btn_Students.Size = new Size(75, 52);
            btn_Students.TabIndex = 12;
            btn_Students.Text = "Students";
            btn_Students.UseVisualStyleBackColor = true;
            btn_Students.Click += btn_Students_Click;
            // 
            // txt_Thema
            // 
            txt_Thema.Location = new Point(160, 449);
            txt_Thema.Name = "txt_Thema";
            txt_Thema.Size = new Size(490, 23);
            txt_Thema.TabIndex = 12;
            // 
            // txt_Inhalt
            // 
            txt_Inhalt.Location = new Point(160, 478);
            txt_Inhalt.Name = "txt_Inhalt";
            txt_Inhalt.Size = new Size(490, 23);
            txt_Inhalt.TabIndex = 13;
            // 
            // txt_Homework
            // 
            txt_Homework.Location = new Point(160, 507);
            txt_Homework.Name = "txt_Homework";
            txt_Homework.Size = new Size(490, 23);
            txt_Homework.TabIndex = 14;
            // 
            // txt_Page
            // 
            txt_Page.Location = new Point(160, 536);
            txt_Page.Name = "txt_Page";
            txt_Page.Size = new Size(490, 23);
            txt_Page.TabIndex = 15;
            // 
            // txt_Note
            // 
            txt_Note.Location = new Point(613, 349);
            txt_Note.Name = "txt_Note";
            txt_Note.Size = new Size(121, 23);
            txt_Note.TabIndex = 0;
            // 
            // cmb_Typ
            // 
            cmb_Typ.FormattingEnabled = true;
            cmb_Typ.Location = new Point(892, 282);
            cmb_Typ.Name = "cmb_Typ";
            cmb_Typ.Size = new Size(121, 23);
            cmb_Typ.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(807, 232);
            label1.Name = "label1";
            label1.Size = new Size(36, 15);
            label1.TabIndex = 3;
            label1.Text = "Note:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(804, 261);
            label2.Name = "label2";
            label2.Size = new Size(74, 15);
            label2.TabIndex = 4;
            label2.Text = "Gewichtung:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(804, 290);
            label3.Name = "label3";
            label3.Size = new Size(29, 15);
            label3.TabIndex = 5;
            label3.Text = "Typ:";
            // 
            // btn_DelGrade
            // 
            btn_DelGrade.Location = new Point(811, 395);
            btn_DelGrade.Name = "btn_DelGrade";
            btn_DelGrade.Size = new Size(75, 20);
            btn_DelGrade.TabIndex = 6;
            btn_DelGrade.Text = "Delete";
            btn_DelGrade.UseVisualStyleBackColor = true;
            btn_DelGrade.Click += btn_DelGrade_Click;
            // 
            // btn_
            // 
            btn_.Location = new Point(811, 366);
            btn_.Name = "btn_";
            btn_.Size = new Size(75, 20);
            btn_.TabIndex = 7;
            btn_.Text = "Edit";
            btn_.UseVisualStyleBackColor = true;
            btn_.Click += btn_EditGrade_Click;
            // 
            // btn_AddGrade
            // 
            btn_AddGrade.Location = new Point(811, 337);
            btn_AddGrade.Name = "btn_AddGrade";
            btn_AddGrade.Size = new Size(75, 20);
            btn_AddGrade.TabIndex = 8;
            btn_AddGrade.Text = "Add";
            btn_AddGrade.UseVisualStyleBackColor = true;
            btn_AddGrade.Click += btn_AddGrade_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(804, 314);
            label4.Name = "label4";
            label4.Size = new Size(82, 15);
            label4.TabIndex = 10;
            label4.Text = "Beschreibung:";
            // 
            // txt_Beschreibung
            // 
            txt_Beschreibung.Location = new Point(892, 311);
            txt_Beschreibung.Name = "txt_Beschreibung";
            txt_Beschreibung.Size = new Size(121, 23);
            txt_Beschreibung.TabIndex = 11;
            // 
            // dtp1
            // 
            dtp1.Location = new Point(666, 449);
            dtp1.Name = "dtp1";
            dtp1.Size = new Size(177, 23);
            dtp1.TabIndex = 16;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(12, 457);
            label5.Name = "label5";
            label5.Size = new Size(47, 15);
            label5.TabIndex = 17;
            label5.Text = "Thema:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(12, 486);
            label6.Name = "label6";
            label6.Size = new Size(40, 15);
            label6.TabIndex = 18;
            label6.Text = "Inhalt:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(12, 515);
            label7.Name = "label7";
            label7.Size = new Size(87, 15);
            label7.TabIndex = 19;
            label7.Text = "Hausaufgaben:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(12, 544);
            label8.Name = "label8";
            label8.Size = new Size(35, 15);
            label8.TabIndex = 20;
            label8.Text = "Seite:";
            // 
            // cmb_Gewichtung
            // 
            cmb_Gewichtung.FormattingEnabled = true;
            cmb_Gewichtung.Location = new Point(892, 253);
            cmb_Gewichtung.Name = "cmb_Gewichtung";
            cmb_Gewichtung.Size = new Size(121, 23);
            cmb_Gewichtung.TabIndex = 21;
            // 
            // cmb_Note
            // 
            cmb_Note.FormattingEnabled = true;
            cmb_Note.Location = new Point(892, 224);
            cmb_Note.Name = "cmb_Note";
            cmb_Note.Size = new Size(121, 23);
            cmb_Note.TabIndex = 22;
            // 
            // btn_AddLH
            // 
            btn_AddLH.Location = new Point(768, 481);
            btn_AddLH.Name = "btn_AddLH";
            btn_AddLH.Size = new Size(75, 20);
            btn_AddLH.TabIndex = 25;
            btn_AddLH.Text = "Add";
            btn_AddLH.UseVisualStyleBackColor = true;
            btn_AddLH.Click += btn_AddLH_Click;
            // 
            // btn_EditLH
            // 
            btn_EditLH.Location = new Point(768, 510);
            btn_EditLH.Name = "btn_EditLH";
            btn_EditLH.Size = new Size(75, 20);
            btn_EditLH.TabIndex = 24;
            btn_EditLH.Text = "Edit";
            btn_EditLH.UseVisualStyleBackColor = true;
            btn_EditLH.Click += btn_EditLH_Click;
            // 
            // btn_DelLH
            // 
            btn_DelLH.Location = new Point(768, 539);
            btn_DelLH.Name = "btn_DelLH";
            btn_DelLH.Size = new Size(75, 20);
            btn_DelLH.TabIndex = 23;
            btn_DelLH.Text = "Delete";
            btn_DelLH.UseVisualStyleBackColor = true;
            btn_DelLH.Click += btn_DelLH_Click;
            // 
            // TeacherClassesForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(1082, 571);
            Controls.Add(btn_AddLH);
            Controls.Add(btn_EditLH);
            Controls.Add(btn_DelLH);
            Controls.Add(cmb_Note);
            Controls.Add(cmb_Gewichtung);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(dtp1);
            Controls.Add(txt_Beschreibung);
            Controls.Add(txt_Page);
            Controls.Add(label4);
            Controls.Add(txt_Homework);
            Controls.Add(btn_AddGrade);
            Controls.Add(btn_);
            Controls.Add(txt_Inhalt);
            Controls.Add(btn_DelGrade);
            Controls.Add(txt_Thema);
            Controls.Add(label3);
            Controls.Add(btn_Students);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(btn_LessonHistory);
            Controls.Add(dgv_Grades);
            Controls.Add(cmb_Typ);
            Controls.Add(dgv_StudentsAndLH);
            Controls.Add(txt_Note);
            Controls.Add(dgv_Classes);
            Name = "TeacherClassesForm";
            Text = "TeacherClassesForm";
            Load += TeacherClassesForm_Load;
            ((System.ComponentModel.ISupportInitialize)dgv_Grades).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgv_StudentsAndLH).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgv_Classes).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button btn_LessonHistory;
        private DataGridView dgv_Grades;
        private DataGridView dgv_StudentsAndLH;
        private DataGridView dgv_Classes;
        private Button btn_Students;
        private TextBox txt_Thema;
        private TextBox txt_Inhalt;
        private TextBox txt_Homework;
        private TextBox txt_Page;
        private TextBox txt_Note;
        private ComboBox cmb_Typ;
        private Label label1;
        private Label label2;
        private Label label3;
        private Button btn_DelGrade;
        private Button btn_;
        private Button btn_AddGrade;
        private Label label4;
        private TextBox txt_Beschreibung;
        private DateTimePicker dtp1;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private ComboBox cmb_Gewichtung;
        private ComboBox cmb_Note;
        private Button btn_AddLH;
        private Button btn_EditLH;
        private Button btn_DelLH;
    }
}