﻿using SchulVerwaltung.Database;
using SchulVerwaltung.Helpers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Schulverwaltung
{
    public partial class StundenPlanForm : Form
    {
        private int selectedStundenplanId = -1;
        private int userKlasseId = -1;

        public StundenPlanForm()
        {
            InitializeComponent();

            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
        }

        private void StundenPlanForm_Load(object sender, EventArgs e)
        {
            if (SessionHelper.Role == SessionHelper.UserRole.Admin)
            {
                LoadFilterClassComboBox();
            }
            ApplyViewMode();
        }

        // Configures form display based on role
        private void ApplyViewMode()
        {
            if (SessionHelper.Role == SessionHelper.UserRole.Admin)
            {
                panel1.Visible = true;
                lbl_Filter.Visible = true;
                cmb_FilterClass.Visible = true;
                
                LoadFilterClassComboBox();
            }
            else if (SessionHelper.Role == SessionHelper.UserRole.Lehrer)
            {
                panel1.Visible = false;
                lbl_Filter.Visible = false;
                cmb_FilterClass.Visible = false;

                LoadTeacherTimetable();
            }
            else
            {
                panel1.Visible = false;
                lbl_Filter.Visible = false;
                cmb_FilterClass.Visible = false;
                dgv_Stundenplan.Dock = DockStyle.Fill;

                DetermineStudentKlasseID();
                LoadStudentTimetable();
            }
        }

        // Sets up Dropdown options
        private void SetupDropdownOptions(int? klasseId = null)
        {
            cmb_Wochentag.Items.Clear();
            cmb_Wochentag.Items.AddRange(new string[] { "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag" });
            cmb_Wochentag.DropDownStyle = ComboBoxStyle.DropDownList;
            if (cmb_Wochentag.Items.Count > 0) cmb_Wochentag.SelectedIndex = 0;

            // Distinguish break and lesson time slots
            string sqlStunden = @"
                        SELECT 
                            StundeID, 
                            CASE 
                                WHEN Bezeichnung LIKE '%Pause%' THEN CONCAT(Bezeichnung, ' (', TIME_FORMAT(Beginn, '%H:%i'), '-', TIME_FORMAT(Ende, '%H:%i'), ')')
                                ELSE CONCAT(
                                    (SELECT COUNT(*) FROM stunden s2 WHERE s2.StundeID <= s1.StundeID AND s2.Bezeichnung NOT LIKE '%Pause%'),
                                    '. Stunde (', TIME_FORMAT(Beginn, '%H:%i'), '-', TIME_FORMAT(Ende, '%H:%i'), ')'
                                )
                            END AS Display 
                        FROM stunden s1 
                        ORDER BY StundeID";

            DataTable dtStunden = DatabaseHelper.ExecuteQuery(sqlStunden);
            cmb_Stunde.DataSource = dtStunden;
            cmb_Stunde.DisplayMember = "Display";
            cmb_Stunde.ValueMember = "StundeID";

            string sqlLehrerFach = @"
                    SELECT lf.LehrerFachID, CONCAT(l.Nachname, ' - ', f.Name) AS Display 
                    FROM lehrer_fach lf
                    JOIN lehrer l ON lf.LehrerID = l.LehrerID
                    JOIN faecher f ON lf.FachID = f.FachID
                    WHERE (@filterByClass = 0 OR lf.KlasseID = @klasseId)
                    ORDER BY l.Nachname, f.Name";

            DataTable dtLehrerFach = DatabaseHelper.ExecuteQuery(sqlLehrerFach,
                ("filterByClass", klasseId.HasValue ? 1 : 0),
                ("klasseId", klasseId ?? 0)
            );

            cmb_Lehrer.DataSource = dtLehrerFach;
            cmb_Lehrer.DisplayMember = "Display";
            cmb_Lehrer.ValueMember = "LehrerFachID";
        }

        // Loads the class filter combo box 
        private void LoadFilterClassComboBox()
        {
            string sql = "SELECT KlasseID, Name FROM klassen ORDER BY Name";
            DataTable dt = DatabaseHelper.ExecuteQuery(sql);
            cmb_FilterClass.DataSource = dt;
            cmb_FilterClass.DisplayMember = "Name";
            cmb_FilterClass.ValueMember = "KlasseID";
        }

        // For students, get the KlasseID from their user ID to filter the timetable accordingly
        private void DetermineStudentKlasseID()
        {
            string sql = "SELECT KlasseID FROM schueler WHERE SchuelerID = @studentId";
            DataTable dt = DatabaseHelper.ExecuteQuery(sql, ("studentId", SessionHelper.CurrentUserID));
            if (dt.Rows.Count > 0)
            {
                userKlasseId = Convert.ToInt32(dt.Rows[0]["KlasseID"]);
            }
        }

        // Populates the Stundenplan grid with display formatting and handles the merging of time slots and pause rows
        private void PopulateStundenplanGrid(string baseSql, params (string, object)[] parameters)
        {
            DataTable displayTable = new DataTable();
            displayTable.Columns.Add("Zeit", typeof(string));
            displayTable.Columns.Add("Montag", typeof(string));
            displayTable.Columns.Add("Dienstag", typeof(string));
            displayTable.Columns.Add("Mittwoch", typeof(string));
            displayTable.Columns.Add("Donnerstag", typeof(string));
            displayTable.Columns.Add("Freitag", typeof(string));

            string sqlStunden = "SELECT StundeID, Bezeichnung, TIME_FORMAT(Beginn, '%H:%i') AS Start, TIME_FORMAT(Ende, '%H:%i') AS Ende FROM stunden ORDER BY StundeID";
            DataTable dtStunden = DatabaseHelper.ExecuteQuery(sqlStunden);

            System.Collections.Generic.Dictionary<int, DataRow> rowMapping = new System.Collections.Generic.Dictionary<int, DataRow>();

            foreach (DataRow stundeRow in dtStunden.Rows)
            {
                int stundeId = Convert.ToInt32(stundeRow["StundeID"]);
                string bezeichnung = stundeRow["Bezeichnung"].ToString();
                string timeInterval = $"{stundeRow["Start"]} - {stundeRow["Ende"]}";

                DataRow newRow = displayTable.NewRow();
                newRow["Zeit"] = timeInterval;

                if (bezeichnung.ToLower().Contains("pause"))
                {
                    newRow["Montag"] = "--- Pause ---";
                    newRow["Dienstag"] = "--- Pause ---";
                    newRow["Mittwoch"] = "--- Pause ---";
                    newRow["Donnerstag"] = "--- Pause ---";
                    newRow["Freitag"] = "--- Pause ---";
                }

                displayTable.Rows.Add(newRow);
                rowMapping[stundeId] = newRow;
            }

            DataTable dataEntries = DatabaseHelper.ExecuteQuery(baseSql, parameters);

            foreach (DataRow entry in dataEntries.Rows)
            {
                int stundeId = Convert.ToInt32(entry["StundeID"]);
                int dayNum = Convert.ToInt32(entry["Wochentag"]);
                string cellDisplay = entry["CellDisplay"].ToString();

                string columnName = dayNum switch
                {
                    1 => "Montag",
                    2 => "Dienstag",
                    3 => "Mittwoch",
                    4 => "Donnerstag",
                    5 => "Freitag",
                    _ => null
                };

                if (columnName != null && rowMapping.ContainsKey(stundeId))
                {
                    rowMapping[stundeId][columnName] = cellDisplay;
                }
            }

            dgv_Stundenplan.DataSource = displayTable;
            ConfigureGridDisplayFormatting();
        }

        // Applies visual formatting to the DataGridView for better readability and distinction of time slots and pause rows
        private void ConfigureGridDisplayFormatting()
        {
            dgv_Stundenplan.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgv_Stundenplan.AllowUserToAddRows = false;
            dgv_Stundenplan.ReadOnly = true;
            dgv_Stundenplan.RowTemplate.Height = 65;
            dgv_Stundenplan.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            dgv_Stundenplan.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            if (dgv_Stundenplan.Columns["Zeit"] != null)
            {
                dgv_Stundenplan.Columns["Zeit"].DefaultCellStyle.Font = new Font(dgv_Stundenplan.Font, FontStyle.Bold);
                dgv_Stundenplan.Columns["Zeit"].DefaultCellStyle.BackColor = Color.LightGray;
            }
        }

        // When the admin changes the class filter, reload teacher-subject options and the timetable grid
        private void cmb_FilterClass_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (SessionHelper.Role == SessionHelper.UserRole.Admin && cmb_FilterClass.SelectedValue != null && cmb_FilterClass.SelectedValue is int activeKlasseId)
            {
                SetupDropdownOptions(activeKlasseId);

                LoadAdminClassTimetable(activeKlasseId);
                ResetInputControls();
            }
        }

        // Admin view
        private void LoadAdminClassTimetable(int klasseId)
        {
            string sql = @"SELECT s.StundeID, s.Wochentag, 
                          CONCAT(f.Kuerzel, ' (', COALESCE(s.Raum, '---'), ')\n', l.Nachname) AS CellDisplay 
                   FROM stundenplan s 
                   JOIN lehrer_fach lf ON s.LehrerFachID = lf.LehrerFachID
                   JOIN faecher f ON lf.FachID = f.FachID 
                   JOIN lehrer l ON lf.LehrerID = l.LehrerID 
                   WHERE lf.KlasseID = @klasseId";

            PopulateStundenplanGrid(sql, ("klasseId", klasseId));
        }

        // Teacher view
        private void LoadTeacherTimetable()
        {
            string sql = @"SELECT s.StundeID, s.Wochentag, 
                          CONCAT(f.Kuerzel, ' (', COALESCE(s.Raum, '---'), ')\n', k.Name) AS CellDisplay 
                   FROM stundenplan s 
                   JOIN lehrer_fach lf ON s.LehrerFachID = lf.LehrerFachID
                   JOIN faecher f ON lf.FachID = f.FachID 
                   JOIN klassen k ON lf.KlasseID = k.KlasseID 
                   WHERE lf.LehrerID = @lehrerId";

            PopulateStundenplanGrid(sql, ("lehrerId", SessionHelper.CurrentUserID));
        }

        // Student view
        private void LoadStudentTimetable()
        {
            if (userKlasseId == -1) return;

            string sql = @"SELECT s.StundeID, s.Wochentag, 
                          CONCAT(f.Name, ' (', COALESCE(s.Raum, '---'), ')\n', l.Nachname) AS CellDisplay 
                   FROM stundenplan s 
                   JOIN lehrer_fach lf ON s.LehrerFachID = lf.LehrerFachID
                   JOIN faecher f ON lf.FachID = f.FachID 
                   JOIN lehrer l ON lf.LehrerID = l.LehrerID 
                   WHERE lf.KlasseID = @klasseId";

            PopulateStundenplanGrid(sql, ("klasseId", userKlasseId));
        }

        // When an admin clicks a cell, populate the input 
        private void dgv_Stundenplan_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (SessionHelper.Role != SessionHelper.UserRole.Admin) return;
            if (e.RowIndex < 0 || e.ColumnIndex < 1) return;

            if (e.ColumnIndex - 1 < cmb_Wochentag.Items.Count) cmb_Wochentag.SelectedIndex = e.ColumnIndex - 1;
            if (e.RowIndex < cmb_Stunde.Items.Count) cmb_Stunde.SelectedIndex = e.RowIndex;

            string cellValue = dgv_Stundenplan.Rows[e.RowIndex].Cells[e.ColumnIndex].Value?.ToString();
            if (!string.IsNullOrEmpty(cellValue) && !cellValue.Contains("--- Pause ---"))
            {
                if (cellValue.Contains("(") && cellValue.Contains(")"))
                {
                    int start = cellValue.IndexOf("(") + 1;
                    int end = cellValue.IndexOf(")");
                    string roomText = cellValue.Substring(start, end - start);

                    txt_Raum.Text = (roomText == "---") ? string.Empty : roomText;
                }

                int targetKlasseId = (int)cmb_FilterClass.SelectedValue;
                int targetStundeId = (int)cmb_Stunde.SelectedValue;
                int targetWochentag = cmb_Wochentag.SelectedIndex + 1;

                string sqlFindId = @"
                    SELECT s.StundenplanID, s.LehrerFachID 
                    FROM stundenplan s                     
                    JOIN lehrer_fach lf ON s.LehrerFachID = lf.LehrerFachID                     
                    WHERE lf.KlasseID = @kId AND s.StundeID = @sId AND s.Wochentag = @wId";

                DataTable dt = DatabaseHelper.ExecuteQuery(sqlFindId, ("kId", targetKlasseId), ("sId", targetStundeId), ("wId", targetWochentag));

                if (dt.Rows.Count > 0)
                {
                    selectedStundenplanId = Convert.ToInt32(dt.Rows[0]["StundenplanID"]);
                    cmb_Lehrer.SelectedValue = Convert.ToInt32(dt.Rows[0]["LehrerFachID"]);
                }
                else
                {
                    selectedStundenplanId = -1;
                }
            }
            else
            {
                txt_Raum.Clear();
            }
        }

        // Add Class Schedule
        private void btn_Add_Click(object sender, EventArgs e)
        {
            if (SessionHelper.Role != SessionHelper.UserRole.Admin) return;
            if (!ValidateAdminInputs()) return;

            try
            {
                string sql = "INSERT INTO stundenplan (LehrerFachID, StundeID, Wochentag, Raum) VALUES (@lehrerFachId, @stundeId, @wochentag, @raum)";
                DatabaseHelper.ExecuteNonQuery(sql,
                    ("lehrerFachId", cmb_Lehrer.SelectedValue),
                    ("stundeId", cmb_Stunde.SelectedValue),
                    ("wochentag", cmb_Wochentag.SelectedIndex + 1),
                    ("raum", string.IsNullOrWhiteSpace(txt_Raum.Text) ? (object)DBNull.Value : txt_Raum.Text.Trim())
                );

                MessageBox.Show("Timetable entry added successfully!",
                    "Success",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                RefreshGrid();
                ResetInputControls();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        // Edit Class Schedule
        private void btn_Edit_Click(object sender, EventArgs e)
        {
            if (SessionHelper.Role != SessionHelper.UserRole.Admin) return;

            if (selectedStundenplanId == -1)
            {
                MessageBox.Show("Please select a lesson slot from the timetable grid to edit first.",
                                "Selection Required", 
                                MessageBoxButtons.OK, 
                                MessageBoxIcon.Warning);
                return;
            }

            if (!ValidateAdminInputs(isEditMode: true)) return;

            try
            {
                string sql = @"
                    UPDATE stundenplan 
                    SET LehrerFachID = @lehrerFachId,
                        StundeID = @stundeId,
                        Wochentag = @wochentag,
                        Raum = @raum                        
                    WHERE StundenplanID = @sId";

                DatabaseHelper.ExecuteNonQuery(sql,
                    ("lehrerFachId", cmb_Lehrer.SelectedValue),
                    ("stundeId", cmb_Stunde.SelectedValue),
                    ("wochentag", cmb_Wochentag.SelectedIndex + 1),
                    ("raum", string.IsNullOrWhiteSpace(txt_Raum.Text) ? (object)DBNull.Value : txt_Raum.Text.Trim()),
                    ("sId", selectedStundenplanId)
                );

                MessageBox.Show("Successfully edited.", 
                    "Success", 
                    MessageBoxButtons.OK, 
                    MessageBoxIcon.Information);

                RefreshGrid();
                ResetInputControls();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", 
                    "Error", 
                    MessageBoxButtons.OK, 
                    MessageBoxIcon.Error);
            }
        }

        // Delete Class Schedule
        private void btn_Del_Click(object sender, EventArgs e)
        {
            if (SessionHelper.Role != SessionHelper.UserRole.Admin) return;
            if (cmb_FilterClass.SelectedValue == null) return;

            var confirm = MessageBox.Show("Do you really want to delete it?",
                "Confirmation",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);
            if (confirm != DialogResult.Yes) return;

            try
            {
                string sql = "DELETE FROM stundenplan WHERE LehrerFachID = @lehrerFachId AND StundeID = @stundeId AND Wochentag = @wochentag";
                DatabaseHelper.ExecuteNonQuery(sql,
                    ("lehrerFachId", cmb_Lehrer.SelectedValue),
                    ("stundeId", cmb_Stunde.SelectedValue),
                    ("wochentag", cmb_Wochentag.SelectedIndex + 1)
                );

                MessageBox.Show("Successfully deleted.",
                    "Success",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                RefreshGrid();
                ResetInputControls();
            }
            catch (Exception ex) { MessageBox.Show($"Error: {ex.Message}"); }
        }

        // Validates admin input fields and checks for scheduling conflicts 
        private bool ValidateAdminInputs(bool isEditMode = false)
        {
            if (cmb_FilterClass.SelectedValue == null || !(cmb_FilterClass.SelectedValue is int activeKlasseId))
            {
                MessageBox.Show("Please select an active target class using the filter first.",
                    "Validation Error",
                    MessageBoxButtons.OK, 
                    MessageBoxIcon.Error);
                return false;
            }
            if (cmb_Wochentag.SelectedItem == null || cmb_Stunde.SelectedValue == null || cmb_Lehrer.SelectedValue == null)
            {
                MessageBox.Show("All input selection fields must contain valid items.",
                    "Validation Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return false;
            }

            int chosenLehrerFachId = (int)cmb_Lehrer.SelectedValue;
            int targetStundeId = (int)cmb_Stunde.SelectedValue;
            int targetWochentag = cmb_Wochentag.SelectedIndex + 1;

            // Break Interval Check
            string sqlPauseCheck = "SELECT Bezeichnung FROM stunden WHERE StundeID = @stundeId";
            DataTable dtPause = DatabaseHelper.ExecuteQuery(sqlPauseCheck, ("stundeId", targetStundeId));
            if (dtPause.Rows.Count > 0 && dtPause.Rows[0]["Bezeichnung"].ToString().ToLower().Contains("pause"))
            {
                MessageBox.Show("Can not schedule a lesson during break.",
                    "Action Blocked",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return false;
            }

            // Time Slot Conflict Check (only for new entries, not when editing existing ones)
            if (!isEditMode)
            {
                string sqlTimeSlotCheck = @"SELECT COUNT(*) FROM stundenplan s
                                    JOIN lehrer_fach lf ON s.LehrerFachID = lf.LehrerFachID
                                    WHERE lf.KlasseID = @kId AND s.StundeID = @sId AND s.Wochentag = @wId";

                DataTable dtSlot = DatabaseHelper.ExecuteQuery(sqlTimeSlotCheck,
                    ("kId", activeKlasseId),
                    ("sId", targetStundeId),
                    ("wId", targetWochentag)
                );

                if (dtSlot.Rows.Count > 0 && Convert.ToInt32(dtSlot.Rows[0][0]) > 0)
                {
                    MessageBox.Show("This time slot is already booked for this class. Use the 'Edit' or 'Delete' options to modify it.",
                                    "Schedule Conflict",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Warning);
                    return false;
                }
            }

            return true;
        }

        // Refreshes the grid
        private void RefreshGrid()
        {
            if (cmb_FilterClass.SelectedValue != null && cmb_FilterClass.SelectedValue is int)
            {
                LoadAdminClassTimetable((int)cmb_FilterClass.SelectedValue);
            }
        }

        // Clears input fields 
        private void ResetInputControls()
        {
            selectedStundenplanId = -1;
            txt_Raum.Clear();
            if (cmb_Wochentag.Items.Count > 0) cmb_Wochentag.SelectedIndex = 0;
            if (cmb_Stunde.Items.Count > 0) cmb_Stunde.SelectedIndex = 0;
            if (cmb_Lehrer.Items.Count > 0) cmb_Lehrer.SelectedIndex = 0;
        }
    }
}