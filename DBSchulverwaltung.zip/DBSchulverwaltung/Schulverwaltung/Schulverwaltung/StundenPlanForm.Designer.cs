﻿namespace Schulverwaltung
{
    partial class StundenPlanForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgv_Stundenplan = new DataGridView();
            cmb_FilterClass = new ComboBox();
            panel1 = new Panel();
            txt_Raum = new TextBox();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            cmb_Lehrer = new ComboBox();
            cmb_Stunde = new ComboBox();
            cmb_Wochentag = new ComboBox();
            btn_Del = new Button();
            btn_Edit = new Button();
            btn_Add = new Button();
            lbl_Filter = new Label();
            ((System.ComponentModel.ISupportInitialize)dgv_Stundenplan).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // dgv_Stundenplan
            // 
            dgv_Stundenplan.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgv_Stundenplan.Location = new Point(12, 12);
            dgv_Stundenplan.Name = "dgv_Stundenplan";
            dgv_Stundenplan.Size = new Size(776, 268);
            dgv_Stundenplan.TabIndex = 0;
            dgv_Stundenplan.CellClick += dgv_Stundenplan_CellClick;
            // 
            // cmb_FilterClass
            // 
            cmb_FilterClass.FormattingEnabled = true;
            cmb_FilterClass.Location = new Point(667, 310);
            cmb_FilterClass.Name = "cmb_FilterClass";
            cmb_FilterClass.Size = new Size(121, 23);
            cmb_FilterClass.TabIndex = 1;
            cmb_FilterClass.SelectedIndexChanged += cmb_FilterClass_SelectedIndexChanged;
            // 
            // panel1
            // 
            panel1.Controls.Add(txt_Raum);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(cmb_Lehrer);
            panel1.Controls.Add(cmb_Stunde);
            panel1.Controls.Add(cmb_Wochentag);
            panel1.Controls.Add(btn_Del);
            panel1.Controls.Add(btn_Edit);
            panel1.Controls.Add(btn_Add);
            panel1.Location = new Point(12, 286);
            panel1.Name = "panel1";
            panel1.Size = new Size(649, 162);
            panel1.TabIndex = 2;
            // 
            // txt_Raum
            // 
            txt_Raum.Location = new Point(83, 93);
            txt_Raum.Name = "txt_Raum";
            txt_Raum.Size = new Size(187, 23);
            txt_Raum.TabIndex = 12;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(3, 96);
            label5.Name = "label5";
            label5.Size = new Size(41, 15);
            label5.TabIndex = 11;
            label5.Text = "Raum:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(1, 64);
            label4.Name = "label4";
            label4.Size = new Size(71, 15);
            label4.TabIndex = 10;
            label4.Text = "Wochentag:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(1, 34);
            label3.Name = "label3";
            label3.Size = new Size(47, 15);
            label3.TabIndex = 9;
            label3.Text = "Stunde:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(1, 5);
            label2.Name = "label2";
            label2.Size = new Size(35, 15);
            label2.TabIndex = 8;
            label2.Text = "Fach:";
            // 
            // cmb_Lehrer
            // 
            cmb_Lehrer.FormattingEnabled = true;
            cmb_Lehrer.Location = new Point(83, 5);
            cmb_Lehrer.Name = "cmb_Lehrer";
            cmb_Lehrer.Size = new Size(187, 23);
            cmb_Lehrer.TabIndex = 5;
            // 
            // cmb_Stunde
            // 
            cmb_Stunde.FormattingEnabled = true;
            cmb_Stunde.Location = new Point(83, 34);
            cmb_Stunde.Name = "cmb_Stunde";
            cmb_Stunde.Size = new Size(187, 23);
            cmb_Stunde.TabIndex = 4;
            // 
            // cmb_Wochentag
            // 
            cmb_Wochentag.FormattingEnabled = true;
            cmb_Wochentag.Location = new Point(83, 64);
            cmb_Wochentag.Name = "cmb_Wochentag";
            cmb_Wochentag.Size = new Size(187, 23);
            cmb_Wochentag.TabIndex = 3;
            // 
            // btn_Del
            // 
            btn_Del.Location = new Point(571, 136);
            btn_Del.Name = "btn_Del";
            btn_Del.Size = new Size(75, 23);
            btn_Del.TabIndex = 2;
            btn_Del.Text = "Delete";
            btn_Del.UseVisualStyleBackColor = true;
            btn_Del.Click += btn_Del_Click;
            // 
            // btn_Edit
            // 
            btn_Edit.Location = new Point(571, 107);
            btn_Edit.Name = "btn_Edit";
            btn_Edit.Size = new Size(75, 23);
            btn_Edit.TabIndex = 1;
            btn_Edit.Text = "Edit";
            btn_Edit.UseVisualStyleBackColor = true;
            btn_Edit.Click += btn_Edit_Click;
            // 
            // btn_Add
            // 
            btn_Add.Location = new Point(571, 78);
            btn_Add.Name = "btn_Add";
            btn_Add.Size = new Size(75, 23);
            btn_Add.TabIndex = 0;
            btn_Add.Text = "Add";
            btn_Add.UseVisualStyleBackColor = true;
            btn_Add.Click += btn_Add_Click;
            // 
            // lbl_Filter
            // 
            lbl_Filter.AutoSize = true;
            lbl_Filter.Location = new Point(667, 289);
            lbl_Filter.Name = "lbl_Filter";
            lbl_Filter.Size = new Size(42, 15);
            lbl_Filter.TabIndex = 11;
            lbl_Filter.Text = "Klasse:";
            // 
            // StundenPlanForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(800, 450);
            Controls.Add(lbl_Filter);
            Controls.Add(panel1);
            Controls.Add(cmb_FilterClass);
            Controls.Add(dgv_Stundenplan);
            Name = "StundenPlanForm";
            Text = "StundenPlanForm";
            Load += StundenPlanForm_Load;
            ((System.ComponentModel.ISupportInitialize)dgv_Stundenplan).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dgv_Stundenplan;
        private ComboBox cmb_FilterClass;
        private Panel panel1;
        private Label label4;
        private Label label3;
        private Label label2;
        private ComboBox cmb_Lehrer;
        private ComboBox cmb_Stunde;
        private ComboBox cmb_Wochentag;
        private Button btn_Del;
        private Button btn_Edit;
        private Button btn_Add;
        private Label lbl_Filter;
        private TextBox txt_Raum;
        private Label label5;
    }
}