﻿namespace Schulverwaltung
{
    partial class ClassesManagementForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgv_Classes = new DataGridView();
            label1 = new Label();
            pnl_LehrerFach = new Panel();
            label5 = new Label();
            label4 = new Label();
            cmb_Klasse = new ComboBox();
            cmb_Lehrer = new ComboBox();
            cmb_Fach = new ComboBox();
            pnl_Fach = new Panel();
            label3 = new Label();
            label2 = new Label();
            textBox2 = new TextBox();
            textBox1 = new TextBox();
            btn_Add = new Button();
            btn_Edit = new Button();
            btn_Del = new Button();
            btn_Toggle = new Button();
            ((System.ComponentModel.ISupportInitialize)dgv_Classes).BeginInit();
            pnl_LehrerFach.SuspendLayout();
            pnl_Fach.SuspendLayout();
            SuspendLayout();
            // 
            // dgv_Classes
            // 
            dgv_Classes.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgv_Classes.Location = new Point(12, 12);
            dgv_Classes.Name = "dgv_Classes";
            dgv_Classes.Size = new Size(776, 275);
            dgv_Classes.TabIndex = 0;
            dgv_Classes.CellClick += dgv_Classes_CellClick;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(3, 3);
            label1.Name = "label1";
            label1.Size = new Size(35, 15);
            label1.TabIndex = 1;
            label1.Text = "Fach:";
            // 
            // pnl_LehrerFach
            // 
            pnl_LehrerFach.Controls.Add(label5);
            pnl_LehrerFach.Controls.Add(label4);
            pnl_LehrerFach.Controls.Add(cmb_Klasse);
            pnl_LehrerFach.Controls.Add(cmb_Lehrer);
            pnl_LehrerFach.Controls.Add(cmb_Fach);
            pnl_LehrerFach.Controls.Add(label1);
            pnl_LehrerFach.Location = new Point(12, 293);
            pnl_LehrerFach.Name = "pnl_LehrerFach";
            pnl_LehrerFach.Size = new Size(319, 154);
            pnl_LehrerFach.TabIndex = 2;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(3, 64);
            label5.Name = "label5";
            label5.Size = new Size(42, 15);
            label5.TabIndex = 6;
            label5.Text = "Klasse:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(3, 35);
            label4.Name = "label4";
            label4.Size = new Size(43, 15);
            label4.TabIndex = 5;
            label4.Text = "Lehrer:";
            // 
            // cmb_Klasse
            // 
            cmb_Klasse.FormattingEnabled = true;
            cmb_Klasse.Location = new Point(53, 61);
            cmb_Klasse.Name = "cmb_Klasse";
            cmb_Klasse.Size = new Size(121, 23);
            cmb_Klasse.TabIndex = 4;
            // 
            // cmb_Lehrer
            // 
            cmb_Lehrer.FormattingEnabled = true;
            cmb_Lehrer.Location = new Point(53, 32);
            cmb_Lehrer.Name = "cmb_Lehrer";
            cmb_Lehrer.Size = new Size(121, 23);
            cmb_Lehrer.TabIndex = 3;
            // 
            // cmb_Fach
            // 
            cmb_Fach.FormattingEnabled = true;
            cmb_Fach.Location = new Point(53, 3);
            cmb_Fach.Name = "cmb_Fach";
            cmb_Fach.Size = new Size(121, 23);
            cmb_Fach.TabIndex = 2;
            // 
            // pnl_Fach
            // 
            pnl_Fach.Controls.Add(label3);
            pnl_Fach.Controls.Add(label2);
            pnl_Fach.Controls.Add(textBox2);
            pnl_Fach.Controls.Add(textBox1);
            pnl_Fach.Location = new Point(12, 293);
            pnl_Fach.Name = "pnl_Fach";
            pnl_Fach.Size = new Size(341, 154);
            pnl_Fach.TabIndex = 3;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(3, 32);
            label3.Name = "label3";
            label3.Size = new Size(42, 15);
            label3.TabIndex = 11;
            label3.Text = "Kürzel:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(3, 8);
            label2.Name = "label2";
            label2.Size = new Size(42, 15);
            label2.TabIndex = 10;
            label2.Text = "Name:";
            // 
            // textBox2
            // 
            textBox2.Location = new Point(51, 32);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(100, 23);
            textBox2.TabIndex = 9;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(51, 3);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(100, 23);
            textBox1.TabIndex = 8;
            // 
            // btn_Add
            // 
            btn_Add.Location = new Point(348, 292);
            btn_Add.Name = "btn_Add";
            btn_Add.Size = new Size(75, 23);
            btn_Add.TabIndex = 0;
            btn_Add.Text = "Add";
            btn_Add.UseVisualStyleBackColor = true;
            btn_Add.Click += btn_Add_Click;
            // 
            // btn_Edit
            // 
            btn_Edit.Location = new Point(348, 321);
            btn_Edit.Name = "btn_Edit";
            btn_Edit.Size = new Size(75, 23);
            btn_Edit.TabIndex = 4;
            btn_Edit.Text = "Edit";
            btn_Edit.UseVisualStyleBackColor = true;
            btn_Edit.Click += btn_Edit_Click;
            // 
            // btn_Del
            // 
            btn_Del.Location = new Point(348, 350);
            btn_Del.Name = "btn_Del";
            btn_Del.Size = new Size(75, 23);
            btn_Del.TabIndex = 5;
            btn_Del.Text = "Delete";
            btn_Del.UseVisualStyleBackColor = true;
            btn_Del.Click += btn_Del_Click;
            // 
            // btn_Toggle
            // 
            btn_Toggle.Location = new Point(348, 402);
            btn_Toggle.Name = "btn_Toggle";
            btn_Toggle.Size = new Size(75, 45);
            btn_Toggle.TabIndex = 7;
            btn_Toggle.Text = "Toggle";
            btn_Toggle.UseVisualStyleBackColor = true;
            btn_Toggle.Click += btn_Toggle_Click;
            // 
            // ClassesManagementForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(800, 450);
            Controls.Add(btn_Toggle);
            Controls.Add(btn_Del);
            Controls.Add(btn_Edit);
            Controls.Add(btn_Add);
            Controls.Add(pnl_Fach);
            Controls.Add(pnl_LehrerFach);
            Controls.Add(dgv_Classes);
            Name = "ClassesManagementForm";
            Text = "ClassesManagementForm";
            Load += ClassesManagementForm_Load;
            ((System.ComponentModel.ISupportInitialize)dgv_Classes).EndInit();
            pnl_LehrerFach.ResumeLayout(false);
            pnl_LehrerFach.PerformLayout();
            pnl_Fach.ResumeLayout(false);
            pnl_Fach.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dgv_Classes;
        private Label label1;
        private Panel pnl_LehrerFach;
        private Panel pnl_Fach;
        private TextBox textBox1;
        private Button btn_Add;
        private Button btn_Edit;
        private Button btn_Del;
        private Button btn_Toggle;
        private TextBox textBox2;
        private Label label5;
        private Label label4;
        private ComboBox cmb_Klasse;
        private ComboBox cmb_Lehrer;
        private ComboBox cmb_Fach;
        private Label label3;
        private Label label2;
    }
}