﻿namespace Schulverwaltung
{
    partial class StudentListForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            cmb_Class = new ComboBox();
            dgv_Students = new DataGridView();
            txt_Vorname = new TextBox();
            txt_Nachname = new TextBox();
            txt_Username = new TextBox();
            txt_Password = new TextBox();
            dtp_Birthdate = new DateTimePicker();
            btn_Edit = new Button();
            btn_Add = new Button();
            btn_Delete = new Button();
            btn_Students = new Button();
            btn_Teachers = new Button();
            label1 = new Label();
            lbl_nachname = new Label();
            label3 = new Label();
            lbl_Mail = new Label();
            lbl_Geburtsdatum = new Label();
            lbl_DropdownCaption = new Label();
            ((System.ComponentModel.ISupportInitialize)dgv_Students).BeginInit();
            SuspendLayout();
            // 
            // cmb_Class
            // 
            cmb_Class.FormattingEnabled = true;
            cmb_Class.Location = new Point(667, 283);
            cmb_Class.Name = "cmb_Class";
            cmb_Class.Size = new Size(121, 23);
            cmb_Class.TabIndex = 0;
            // 
            // dgv_Students
            // 
            dgv_Students.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgv_Students.Location = new Point(22, 12);
            dgv_Students.Name = "dgv_Students";
            dgv_Students.Size = new Size(766, 265);
            dgv_Students.TabIndex = 1;
            dgv_Students.CellClick += dgv_Students_CellClick;
            // 
            // txt_Vorname
            // 
            txt_Vorname.Location = new Point(119, 283);
            txt_Vorname.Name = "txt_Vorname";
            txt_Vorname.Size = new Size(190, 23);
            txt_Vorname.TabIndex = 2;
            // 
            // txt_Nachname
            // 
            txt_Nachname.Location = new Point(119, 312);
            txt_Nachname.Name = "txt_Nachname";
            txt_Nachname.Size = new Size(190, 23);
            txt_Nachname.TabIndex = 3;
            // 
            // txt_Username
            // 
            txt_Username.Location = new Point(119, 341);
            txt_Username.Name = "txt_Username";
            txt_Username.Size = new Size(190, 23);
            txt_Username.TabIndex = 4;
            // 
            // txt_Password
            // 
            txt_Password.Location = new Point(119, 370);
            txt_Password.Name = "txt_Password";
            txt_Password.Size = new Size(190, 23);
            txt_Password.TabIndex = 5;
            // 
            // dtp_Birthdate
            // 
            dtp_Birthdate.Location = new Point(119, 399);
            dtp_Birthdate.Name = "dtp_Birthdate";
            dtp_Birthdate.Size = new Size(190, 23);
            dtp_Birthdate.TabIndex = 6;
            // 
            // btn_Edit
            // 
            btn_Edit.Location = new Point(713, 340);
            btn_Edit.Name = "btn_Edit";
            btn_Edit.Size = new Size(75, 23);
            btn_Edit.TabIndex = 8;
            btn_Edit.Text = "Edit";
            btn_Edit.UseVisualStyleBackColor = true;
            btn_Edit.Click += btn_Edit_Click;
            // 
            // btn_Add
            // 
            btn_Add.Location = new Point(713, 369);
            btn_Add.Name = "btn_Add";
            btn_Add.Size = new Size(75, 23);
            btn_Add.TabIndex = 9;
            btn_Add.Text = "Add";
            btn_Add.UseVisualStyleBackColor = true;
            btn_Add.Click += btn_Add_Click;
            // 
            // btn_Delete
            // 
            btn_Delete.Location = new Point(713, 399);
            btn_Delete.Name = "btn_Delete";
            btn_Delete.Size = new Size(75, 23);
            btn_Delete.TabIndex = 10;
            btn_Delete.Text = "Delete";
            btn_Delete.UseVisualStyleBackColor = true;
            btn_Delete.Click += btn_Delete_Click;
            // 
            // btn_Students
            // 
            btn_Students.Location = new Point(623, 339);
            btn_Students.Name = "btn_Students";
            btn_Students.Size = new Size(84, 53);
            btn_Students.TabIndex = 11;
            btn_Students.Text = "Students";
            btn_Students.UseVisualStyleBackColor = true;
            btn_Students.Click += btn_Students_Click;
            // 
            // btn_Teachers
            // 
            btn_Teachers.Location = new Point(623, 399);
            btn_Teachers.Name = "btn_Teachers";
            btn_Teachers.Size = new Size(84, 53);
            btn_Teachers.TabIndex = 12;
            btn_Teachers.Text = "Teachers";
            btn_Teachers.UseVisualStyleBackColor = true;
            btn_Teachers.Click += btn_Teachers_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(22, 291);
            label1.Name = "label1";
            label1.Size = new Size(42, 15);
            label1.TabIndex = 13;
            label1.Text = "Name:";
            // 
            // lbl_nachname
            // 
            lbl_nachname.AutoSize = true;
            lbl_nachname.Location = new Point(22, 315);
            lbl_nachname.Name = "lbl_nachname";
            lbl_nachname.Size = new Size(68, 15);
            lbl_nachname.TabIndex = 14;
            lbl_nachname.Text = "Nachname:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(22, 341);
            label3.Name = "label3";
            label3.Size = new Size(63, 15);
            label3.TabIndex = 15;
            label3.Text = "Username:";
            // 
            // lbl_Mail
            // 
            lbl_Mail.AutoSize = true;
            lbl_Mail.Location = new Point(22, 369);
            lbl_Mail.Name = "lbl_Mail";
            lbl_Mail.Size = new Size(44, 15);
            lbl_Mail.TabIndex = 16;
            lbl_Mail.Text = "E-Mail:";
            // 
            // lbl_Geburtsdatum
            // 
            lbl_Geburtsdatum.AutoSize = true;
            lbl_Geburtsdatum.Location = new Point(22, 399);
            lbl_Geburtsdatum.Name = "lbl_Geburtsdatum";
            lbl_Geburtsdatum.Size = new Size(58, 15);
            lbl_Geburtsdatum.TabIndex = 17;
            lbl_Geburtsdatum.Text = "Birthdate:";
            // 
            // lbl_DropdownCaption
            // 
            lbl_DropdownCaption.AutoSize = true;
            lbl_DropdownCaption.Location = new Point(623, 286);
            lbl_DropdownCaption.Name = "lbl_DropdownCaption";
            lbl_DropdownCaption.Size = new Size(42, 15);
            lbl_DropdownCaption.TabIndex = 18;
            lbl_DropdownCaption.Text = "Klasse:";
            // 
            // StudentListForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(800, 462);
            Controls.Add(lbl_DropdownCaption);
            Controls.Add(lbl_Geburtsdatum);
            Controls.Add(lbl_Mail);
            Controls.Add(label3);
            Controls.Add(lbl_nachname);
            Controls.Add(label1);
            Controls.Add(btn_Teachers);
            Controls.Add(btn_Students);
            Controls.Add(btn_Delete);
            Controls.Add(btn_Add);
            Controls.Add(btn_Edit);
            Controls.Add(dtp_Birthdate);
            Controls.Add(txt_Password);
            Controls.Add(txt_Username);
            Controls.Add(txt_Nachname);
            Controls.Add(txt_Vorname);
            Controls.Add(dgv_Students);
            Controls.Add(cmb_Class);
            Name = "StudentListForm";
            Text = "Students";
            Load += StudentListForm_Load;
            ((System.ComponentModel.ISupportInitialize)dgv_Students).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox cmb_Class;
        private DataGridView dgv_Students;
        private TextBox txt_Vorname;
        private TextBox txt_Nachname;
        private TextBox txt_Username;
        private TextBox txt_Password;
        private DateTimePicker dtp_Birthdate;
        private Button btn_Edit;
        private Button btn_Add;
        private Button btn_Delete;
        private Button btn_Students;
        private Button btn_Teachers;
        private Label label1;
        private Label lbl_nachname;
        private Label label3;
        private Label lbl_Mail;
        private Label lbl_Geburtsdatum;
        private Label lbl_DropdownCaption;
    }
}