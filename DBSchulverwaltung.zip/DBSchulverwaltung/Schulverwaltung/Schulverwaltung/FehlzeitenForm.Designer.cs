﻿namespace Schulverwaltung
{
    partial class FehlzeitenForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgv_Fehlzeiten = new DataGridView();
            num_Stunden = new NumericUpDown();
            chk_Entschuldigt = new CheckBox();
            dtp_Datum = new DateTimePicker();
            txt_Grund = new TextBox();
            cmb_Klasse = new ComboBox();
            cmb_Schueler = new ComboBox();
            label1 = new Label();
            label3 = new Label();
            label4 = new Label();
            label2 = new Label();
            label5 = new Label();
            pnl_1 = new Panel();
            btn_Del = new Button();
            btn_Edit = new Button();
            btn_Add = new Button();
            ((System.ComponentModel.ISupportInitialize)dgv_Fehlzeiten).BeginInit();
            ((System.ComponentModel.ISupportInitialize)num_Stunden).BeginInit();
            pnl_1.SuspendLayout();
            SuspendLayout();
            // 
            // dgv_Fehlzeiten
            // 
            dgv_Fehlzeiten.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgv_Fehlzeiten.Location = new Point(12, 12);
            dgv_Fehlzeiten.Name = "dgv_Fehlzeiten";
            dgv_Fehlzeiten.Size = new Size(776, 237);
            dgv_Fehlzeiten.TabIndex = 0;
            dgv_Fehlzeiten.CellClick += dgv_Fehlzeiten_CellClick;
            // 
            // num_Stunden
            // 
            num_Stunden.Location = new Point(66, 6);
            num_Stunden.Name = "num_Stunden";
            num_Stunden.Size = new Size(120, 23);
            num_Stunden.TabIndex = 1;
            // 
            // chk_Entschuldigt
            // 
            chk_Entschuldigt.AutoSize = true;
            chk_Entschuldigt.Location = new Point(66, 93);
            chk_Entschuldigt.Name = "chk_Entschuldigt";
            chk_Entschuldigt.Size = new Size(92, 19);
            chk_Entschuldigt.TabIndex = 2;
            chk_Entschuldigt.Text = "Entschuldigt";
            chk_Entschuldigt.UseVisualStyleBackColor = true;
            // 
            // dtp_Datum
            // 
            dtp_Datum.Location = new Point(66, 35);
            dtp_Datum.Name = "dtp_Datum";
            dtp_Datum.Size = new Size(200, 23);
            dtp_Datum.TabIndex = 3;
            // 
            // txt_Grund
            // 
            txt_Grund.Location = new Point(66, 64);
            txt_Grund.Name = "txt_Grund";
            txt_Grund.Size = new Size(100, 23);
            txt_Grund.TabIndex = 4;
            // 
            // cmb_Klasse
            // 
            cmb_Klasse.FormattingEnabled = true;
            cmb_Klasse.Location = new Point(359, 3);
            cmb_Klasse.Name = "cmb_Klasse";
            cmb_Klasse.Size = new Size(121, 23);
            cmb_Klasse.TabIndex = 5;
            cmb_Klasse.SelectedIndexChanged += cmb_Klasse_SelectedIndexChanged;
            // 
            // cmb_Schueler
            // 
            cmb_Schueler.FormattingEnabled = true;
            cmb_Schueler.Location = new Point(359, 32);
            cmb_Schueler.Name = "cmb_Schueler";
            cmb_Schueler.Size = new Size(121, 23);
            cmb_Schueler.TabIndex = 6;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(3, 8);
            label1.Name = "label1";
            label1.Size = new Size(54, 15);
            label1.TabIndex = 7;
            label1.Text = "Stunden:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(3, 43);
            label3.Name = "label3";
            label3.Size = new Size(46, 15);
            label3.TabIndex = 9;
            label3.Text = "Datum:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(3, 67);
            label4.Name = "label4";
            label4.Size = new Size(43, 15);
            label4.TabIndex = 10;
            label4.Text = "Grund:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(288, 6);
            label2.Name = "label2";
            label2.Size = new Size(42, 15);
            label2.TabIndex = 11;
            label2.Text = "Klasse:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(288, 35);
            label5.Name = "label5";
            label5.Size = new Size(49, 15);
            label5.TabIndex = 12;
            label5.Text = "Schüler:";
            // 
            // pnl_1
            // 
            pnl_1.Controls.Add(btn_Del);
            pnl_1.Controls.Add(btn_Edit);
            pnl_1.Controls.Add(btn_Add);
            pnl_1.Controls.Add(label1);
            pnl_1.Controls.Add(label5);
            pnl_1.Controls.Add(num_Stunden);
            pnl_1.Controls.Add(label2);
            pnl_1.Controls.Add(cmb_Schueler);
            pnl_1.Controls.Add(chk_Entschuldigt);
            pnl_1.Controls.Add(cmb_Klasse);
            pnl_1.Controls.Add(label4);
            pnl_1.Controls.Add(dtp_Datum);
            pnl_1.Controls.Add(label3);
            pnl_1.Controls.Add(txt_Grund);
            pnl_1.Location = new Point(15, 260);
            pnl_1.Name = "pnl_1";
            pnl_1.Size = new Size(485, 181);
            pnl_1.TabIndex = 13;
            // 
            // btn_Del
            // 
            btn_Del.Location = new Point(405, 151);
            btn_Del.Name = "btn_Del";
            btn_Del.Size = new Size(75, 23);
            btn_Del.TabIndex = 15;
            btn_Del.Text = "Delete";
            btn_Del.UseVisualStyleBackColor = true;
            btn_Del.Click += btn_Delete_Click;
            // 
            // btn_Edit
            // 
            btn_Edit.Location = new Point(405, 122);
            btn_Edit.Name = "btn_Edit";
            btn_Edit.Size = new Size(75, 23);
            btn_Edit.TabIndex = 14;
            btn_Edit.Text = "Edit";
            btn_Edit.UseVisualStyleBackColor = true;
            btn_Edit.Click += btn_Edit_Click;
            // 
            // btn_Add
            // 
            btn_Add.Location = new Point(405, 93);
            btn_Add.Name = "btn_Add";
            btn_Add.Size = new Size(75, 23);
            btn_Add.TabIndex = 13;
            btn_Add.Text = "Add";
            btn_Add.UseVisualStyleBackColor = true;
            btn_Add.Click += btn_Add_Click;
            // 
            // FehlzeitenForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(800, 450);
            Controls.Add(pnl_1);
            Controls.Add(dgv_Fehlzeiten);
            Name = "FehlzeitenForm";
            Text = "FehlzeitenForm";
            Load += FehlzeitenForm_Load;
            ((System.ComponentModel.ISupportInitialize)dgv_Fehlzeiten).EndInit();
            ((System.ComponentModel.ISupportInitialize)num_Stunden).EndInit();
            pnl_1.ResumeLayout(false);
            pnl_1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dgv_Fehlzeiten;
        private NumericUpDown num_Stunden;
        private CheckBox chk_Entschuldigt;
        private DateTimePicker dtp_Datum;
        private TextBox txt_Grund;
        private ComboBox cmb_Klasse;
        private ComboBox cmb_Schueler;
        private Label label1;
        private Label label3;
        private Label label4;
        private Label label2;
        private Label label5;
        private Panel pnl_1;
        private Button btn_Del;
        private Button btn_Edit;
        private Button btn_Add;
    }
}