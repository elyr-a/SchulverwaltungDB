﻿using SchulVerwaltung.Database;
using SchulVerwaltung.Helpers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Schulverwaltung
{
    public partial class TeacherClassesForm : Form
    {
        private enum ViewMode { Students, LessonHistory }
        private ViewMode currentMode = ViewMode.Students;

        private int selectedLehrerFachId = -1;
        private int selectedKlasseId = -1;
        private int selectedFachId = -1;
        private int selectedStudentId = -1;
        private int selectedGradeId = -1;
        private int selectedHistoryId = -1;

        public TeacherClassesForm()
        {
            InitializeComponent();

            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
        }

        private void TeacherClassesForm_Load(object sender, EventArgs e)
        {
            LoadClassesDropdown();
            SetupComboBoxes();
            UpdateViewMode();
        }

        // Initializes the combo boxes with predefined values and sets default selections
        private void SetupComboBoxes()
        {
            cmb_Note.Items.Clear();
            cmb_Note.Items.AddRange(new string[] {
                "1.0", "1.3", "1.7",
                "2.0", "2.3", "2.7",
                "3.0", "3.3", "3.7",
                "4.0", "4.3", "4.7",
                "5.0", "6.0"
            });
            cmb_Note.DropDownStyle = ComboBoxStyle.DropDownList;
            if (cmb_Note.Items.Count > 0) cmb_Note.SelectedIndex = 0;

            cmb_Gewichtung.Items.Clear();
            cmb_Gewichtung.Items.AddRange(new string[] { "100%", "75%", "50%", "40%", "30%", "25%", "20%", "10%" });
            cmb_Gewichtung.DropDownStyle = ComboBoxStyle.DropDownList;
            if (cmb_Gewichtung.Items.Count > 0) cmb_Gewichtung.SelectedIndex = 0;

            cmb_Typ.Items.Clear();
            cmb_Typ.Items.AddRange(new string[] { "Klassenarbeit", "Hausaufgabe", "Muendlich", "Test", "Sonstige" });
            cmb_Typ.DropDownStyle = ComboBoxStyle.DropDownList;
            if (cmb_Typ.Items.Count > 0) cmb_Typ.SelectedIndex = 4;
        }

        // Loads the classes and subjects 
        private void LoadClassesDropdown()
        {
            string sql;
            DataTable dt;

            if (SessionHelper.Role == SessionHelper.UserRole.Admin)
            {
                sql = "SELECT lf.LehrerFachID, lf.KlasseID, lf.FachID, k.Name AS 'Klasse', f.Name AS 'Fach' " +
                      "FROM lehrer_fach lf " +
                      "JOIN klassen k ON lf.KlasseID = k.KlasseID " +
                      "JOIN faecher f ON lf.FachID = f.FachID " +
                      "ORDER BY k.Name, f.Name";
                dt = DatabaseHelper.ExecuteQuery(sql);
            }
            else
            {
                sql = "SELECT lf.LehrerFachID, lf.KlasseID, lf.FachID, k.Name AS 'Klasse', f.Name AS 'Fach' " +
                      "FROM lehrer_fach lf " +
                      "JOIN klassen k ON lf.KlasseID = k.KlasseID " +
                      "JOIN faecher f ON lf.FachID = f.FachID " +
                      "WHERE lf.LehrerID = @lehrerId " +
                      "ORDER BY k.Name, f.Name";
                dt = DatabaseHelper.ExecuteQuery(sql, ("lehrerId", SessionHelper.CurrentUserID));
            }

            dgv_Classes.DataSource = dt;
            dgv_Classes.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            if (dgv_Classes.Columns["KlasseID"] != null) dgv_Classes.Columns["KlasseID"].Visible = false;
            if (dgv_Classes.Columns["FachID"] != null) dgv_Classes.Columns["FachID"].Visible = false;
            if (dgv_Classes.Columns["LehrerFachID"] != null) dgv_Classes.Columns["LehrerFachID"].Visible = false;
        }

        // When a class is selected, load the students or lesson history 
        private void dgv_Classes_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgv_Classes.Rows[e.RowIndex];
                selectedLehrerFachId = Convert.ToInt32(row.Cells["LehrerFachID"].Value);
                selectedKlasseId = Convert.ToInt32(row.Cells["KlasseID"].Value);
                selectedFachId = Convert.ToInt32(row.Cells["FachID"].Value);

                RefreshCenterGrid();

                selectedStudentId = -1;
                dgv_Grades.DataSource = null;
                ResetGradeInputFields();
            }
        }

        // Refreshes the DGV based on the current view mode 
        private void RefreshCenterGrid()
        {
            if (selectedLehrerFachId == -1) return;

            if (currentMode == ViewMode.Students)
            {
                LoadStudentsRoster();
            }
            else
            {
                LoadLessonHistoryLog();
            }
        }

        // Loads the list of students for the selected class
        private void LoadStudentsRoster()
        {
            string sql = "SELECT SchuelerID, Vorname, Nachname FROM schueler WHERE KlasseID = @klasseId ORDER BY Nachname, Vorname";
            DataTable dt = DatabaseHelper.ExecuteQuery(sql, ("klasseId", selectedKlasseId));

            dgv_StudentsAndLH.DataSource = dt;
            if (dgv_StudentsAndLH.Columns["SchuelerID"] != null) dgv_StudentsAndLH.Columns["SchuelerID"].Visible = false;
            dgv_StudentsAndLH.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        // Loads the lesson history log for the selected class and subject
        private void LoadLessonHistoryLog()
        {
            string sql = "SELECT HistorieID, Datum AS 'Date', Thema AS 'Topic', Inhalt AS 'Summary', Hausaufgaben AS 'Homework', Seite AS 'Page' " +
                         "FROM unterrichtshistorie " +
                         "WHERE LehrerFachID = @lehrerFachId " + 
                         "ORDER BY Datum DESC";

            DataTable dt = DatabaseHelper.ExecuteQuery(sql, ("lehrerFachId", selectedLehrerFachId));
            dgv_StudentsAndLH.DataSource = dt;

            if (dgv_StudentsAndLH.Columns["HistorieID"] != null) dgv_StudentsAndLH.Columns["HistorieID"].Visible = false;
            dgv_StudentsAndLH.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        // When a student or lesson history entry is selected, populate the right panel with details
        private void dgv_StudentsAndLH_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || dgv_StudentsAndLH.Rows[e.RowIndex].IsNewRow) return;

            DataGridViewRow row = dgv_StudentsAndLH.Rows[e.RowIndex];

            if (currentMode == ViewMode.Students)
            {
                selectedStudentId = Convert.ToInt32(row.Cells["SchuelerID"].Value);
                LoadStudentGrades(selectedStudentId);
            }
            else
            {
                if (dgv_StudentsAndLH.Columns["HistorieID"] != null)
                    selectedHistoryId = Convert.ToInt32(row.Cells["HistorieID"].Value);

                txt_Thema.Text = row.Cells["Topic"].Value?.ToString() ?? "";
                txt_Inhalt.Text = row.Cells["Summary"].Value?.ToString() ?? "";
                txt_Homework.Text = row.Cells["Homework"].Value?.ToString() ?? "";
                txt_Page.Text = row.Cells["Page"].Value?.ToString() ?? "";

                if (DateTime.TryParse(row.Cells["Date"].Value?.ToString(), out DateTime logDate))
                    dtp1.Value = logDate;
            }
        }

        // Loads the grades for the selected student and subject 
        private void LoadStudentGrades(int studentId)
        {
            string sql = "SELECT NotenID, Note, Gewichtung, Typ, Beschreibung, DATE_FORMAT(Datum, '%d.%m.%Y') AS 'Datum' " +
                         "FROM noten WHERE SchuelerID = @studentId AND LehrerFachID = @lehrerFachId ORDER BY Datum DESC";

            DataTable dt = DatabaseHelper.ExecuteQuery(sql, ("studentId", studentId), ("lehrerFachId", selectedLehrerFachId));
            dgv_Grades.DataSource = dt;

            if (dgv_Grades.Columns["NotenID"] != null) dgv_Grades.Columns["NotenID"].Visible = false;
            dgv_Grades.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        // When a grade is selected, populate the input fields for editing
        private void dgv_Grades_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgv_Grades.Rows[e.RowIndex];

                if (row.Cells["NotenID"].Value == null || row.Cells["NotenID"].Value == DBNull.Value)
                    return;

                selectedGradeId = Convert.ToInt32(row.Cells["NotenID"].Value);

                // Convert decimal grade to standard string representation format ("1.0", "4.0")
                string cleanNote = Convert.ToDecimal(row.Cells["Note"].Value).ToString("0.0", System.Globalization.CultureInfo.InvariantCulture);
                SetComboBoxSelectedValue(cmb_Note, cleanNote);

                // Re-calculate the fractional database weight back to its percentage UI string format ("50%")
                decimal dbGewichtung = Convert.ToDecimal(row.Cells["Gewichtung"].Value);
                string percentageString = $"{(dbGewichtung * 100):0}%";
                SetComboBoxSelectedValue(cmb_Gewichtung, percentageString);

                SetComboBoxSelectedValue(cmb_Typ, row.Cells["Typ"].Value?.ToString());
                txt_Beschreibung.Text = row.Cells["Beschreibung"].Value?.ToString() ?? "";
            }
        }

        // Helper method to set ComboBox selected value safely
        private void SetComboBoxSelectedValue(ComboBox cmb, string value)
        {
            if (value != null && cmb.Items.Contains(value))
                cmb.SelectedItem = value;
            else if (cmb.Items.Count > 0)
                cmb.SelectedIndex = 0;
        }

        // View mode toggle
        private void btn_Students_Click(object sender, EventArgs e)
        {
            currentMode = ViewMode.Students;
            UpdateViewMode();
            RefreshCenterGrid();
        }

        private void btn_LessonHistory_Click(object sender, EventArgs e)
        {
            currentMode = ViewMode.LessonHistory;
            UpdateViewMode();
            RefreshCenterGrid();
        }

        private void UpdateViewMode()
        {
            if (currentMode == ViewMode.Students)
            {
                btn_Students.BackColor = Color.LightGreen;
                btn_LessonHistory.BackColor = SystemColors.Control;
            }
            else
            {
                btn_LessonHistory.BackColor = Color.LightGreen;
                btn_Students.BackColor = SystemColors.Control;
            }
        }

        // Grade management
        // Add, Edit, Delete grades for selected student and subject
        private void btn_AddGrade_Click(object sender, EventArgs e)
        {
            if (selectedStudentId == -1)
            {
                MessageBox.Show("Please select a student first.",
                    "No Selection");
                return;
            }

            string selectedNote = cmb_Note.SelectedItem?.ToString();
            string selectedTyp = cmb_Typ.SelectedItem?.ToString() ?? "Sonstige";
            string beschreibung = txt_Beschreibung.Text.Trim();

            // Process percentage drop selections back to dec
            string rawWeightStr = cmb_Gewichtung.SelectedItem?.ToString().Replace("%", "") ?? "100";
            decimal dbGewichtungValue = decimal.Parse(rawWeightStr, System.Globalization.CultureInfo.InvariantCulture) / 100m;

            string sql = "INSERT INTO noten (SchuelerID, LehrerFachID, Note, Typ, Gewichtung, Beschreibung, Datum) " + 
                         "VALUES (@studentId, @lehrerFachId, @note, @typ, @gewichtung, @beschreibung, @datum)";

            DatabaseHelper.ExecuteNonQuery(sql,
                ("studentId", selectedStudentId),
                ("lehrerFachId", selectedLehrerFachId),
                ("note", decimal.Parse(selectedNote, System.Globalization.CultureInfo.InvariantCulture)),
                ("typ", selectedTyp),
                ("gewichtung", dbGewichtungValue),
                ("beschreibung", beschreibung),
                ("datum", dtp1.Value.ToString("yyyy-MM-dd"))
            );

            MessageBox.Show("Grade added.",
                "Success",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
            LoadStudentGrades(selectedStudentId);
            ResetGradeInputFields();
        }

        // Edit
        private void btn_EditGrade_Click(object sender, EventArgs e)
        {
            if (selectedGradeId == -1) return;

            string rawWeightStr = cmb_Gewichtung.SelectedItem?.ToString().Replace("%", "") ?? "100";
            decimal dbGewichtungValue = decimal.Parse(rawWeightStr, System.Globalization.CultureInfo.InvariantCulture) / 100m;

            string sql = "UPDATE noten SET Note = @note, Gewichtung = @gewichtung, Typ = @typ, Beschreibung = @beschreibung, Datum = @datum WHERE NotenID = @gradeId";
            DatabaseHelper.ExecuteNonQuery(sql,
                ("note", decimal.Parse(cmb_Note.SelectedItem?.ToString(), System.Globalization.CultureInfo.InvariantCulture)),
                ("gewichtung", dbGewichtungValue),
                ("typ", cmb_Typ.SelectedItem?.ToString()),
                ("beschreibung", txt_Beschreibung.Text.Trim()),
                ("datum", dtp1.Value.ToString("yyyy-MM-dd")),
                ("gradeId", selectedGradeId)
            );

            MessageBox.Show("Succesfully edited.",
                "Success",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
            LoadStudentGrades(selectedStudentId);
            ResetGradeInputFields();
        }

        // Delete
        private void btn_DelGrade_Click(object sender, EventArgs e)
        {
            if (selectedGradeId == -1) return;

            var dialogResult = MessageBox.Show("Are you sure you want to delete it?",
                "Confirmation",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);
            if (dialogResult != DialogResult.Yes) return;

            string sql = "DELETE FROM noten WHERE NotenID = @gradeId";
            DatabaseHelper.ExecuteNonQuery(sql, ("gradeId", selectedGradeId));

            MessageBox.Show("Deleted.",
                "Success",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
            LoadStudentGrades(selectedStudentId);
            ResetGradeInputFields();
        }

        private void ResetGradeInputFields()
        {
            selectedGradeId = -1;
            txt_Beschreibung.Clear();
            if (cmb_Note.Items.Count > 0) cmb_Note.SelectedIndex = 0;
            if (cmb_Gewichtung.Items.Count > 0) cmb_Gewichtung.SelectedIndex = 0;
            if (cmb_Typ.Items.Count > 0) cmb_Typ.SelectedIndex = 4;
        }

        // Lesson history management
        // Add 
        private void btn_AddLH_Click(object sender, EventArgs e)
        {
            if (selectedLehrerFachId == -1) 
            {
                MessageBox.Show("Please select a Class and Subject from the top grid first.", 
                    "No Selection");
                return;
            }

            string sql = "INSERT INTO unterrichtshistorie (LehrerFachID, Datum, Thema, Inhalt, Hausaufgaben, Seite) " + 
                         "VALUES (@lehrerFachId, @datum, @thema, @inhalt, @hausaufgaben, @seite)";

            DatabaseHelper.ExecuteNonQuery(sql,
                ("lehrerFachId", selectedLehrerFachId),
                ("datum", dtp1.Value.ToString("yyyy-MM-dd")),
                ("thema", txt_Thema.Text.Trim()),
                ("inhalt", txt_Inhalt.Text.Trim()),
                ("hausaufgaben", txt_Homework.Text.Trim()),
                ("seite", txt_Page.Text.Trim())
            );

            MessageBox.Show("Lesson history added.", 
                "Success", 
                MessageBoxButtons.OK, 
                MessageBoxIcon.Information);
            RefreshCenterGrid();
            ResetLessonHistoryFields();
        }

        private void btn_EditLH_Click(object sender, EventArgs e)
        {
            if (selectedHistoryId == -1)
            {
                MessageBox.Show("Please select a lesson history entry from the grid to edit.", 
                    "No Selection");
                return;
            }

            string sql = "UPDATE unterrichtshistorie SET Datum = @datum, Thema = @thema, Inhalt = @inhalt, Hausaufgaben = @hausaufgaben, Seite = @seite WHERE HistorieID = @historyId";

            DatabaseHelper.ExecuteNonQuery(sql,
                ("datum", dtp1.Value.ToString("yyyy-MM-dd")),
                ("thema", txt_Thema.Text.Trim()),
                ("inhalt", txt_Inhalt.Text.Trim()),
                ("hausaufgaben", txt_Homework.Text.Trim()),
                ("seite", txt_Page.Text.Trim()),
                ("historyId", selectedHistoryId)
            );

            MessageBox.Show("Lesson history edited.", 
                "Success", 
                MessageBoxButtons.OK, 
                MessageBoxIcon.Information);
            RefreshCenterGrid();
            ResetLessonHistoryFields();
        }

        private void btn_DelLH_Click(object sender, EventArgs e)
        {
            if (selectedHistoryId == -1)
            {
                MessageBox.Show("Please select a lesson history entry to delete.", "No Selection");
                return;
            }

            var dialogResult = MessageBox.Show("Are you sure you want to delete this lesson history entry?",
                "Confirmation", 
                MessageBoxButtons.YesNo, 
                MessageBoxIcon.Question);

            if (dialogResult != DialogResult.Yes) return;

            string sql = "DELETE FROM unterrichtshistorie WHERE HistorieID = @historyId";
            DatabaseHelper.ExecuteNonQuery(sql, ("historyId", selectedHistoryId));

            MessageBox.Show("Lesson history deleted.", 
                "Success", 
                MessageBoxButtons.OK, 
                MessageBoxIcon.Information);
            RefreshCenterGrid();
            ResetLessonHistoryFields();
        }

        private void ResetLessonHistoryFields()
        {
            selectedHistoryId = -1;
            txt_Thema.Clear();
            txt_Inhalt.Clear();
            txt_Homework.Clear();
            txt_Page.Clear();
            dtp1.Value = DateTime.Now;
        }
    }
}
